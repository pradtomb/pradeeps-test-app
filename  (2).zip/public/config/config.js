var config_module = angular.module('bot-config-ui.config', [])
	.constant('botConfigGetAll','http://localhost:8080/botConfig/platformLookup/getAllConfig')
	.constant('APP_VERSION','0.1')
	.constant('FIRST_URL','http://www.google.com')
;