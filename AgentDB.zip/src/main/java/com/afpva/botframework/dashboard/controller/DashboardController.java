package com.afpva.botframework.dashboard.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.afpva.botframework.dashboard.dto.DashboardDTO;
import com.afpva.botframework.dashboard.dto.FormRequestDTO;
import com.afpva.botframework.dashboard.service.DashboardService;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {
	@Autowired
	DashboardService dashboardService;
	
	
	
	
	@RequestMapping(value = "/getConversation/{conersationId}", method = RequestMethod.GET,produces="application/json")
	public  ResponseEntity<List<DashboardDTO>> getConversation(@PathVariable("conersationId") String conersationId) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<DashboardDTO> dashList= dashboardService.findAll(conersationId);
		try {
			result.put("operation_result", "success");
			result.put("response", dashList);
		} catch (Exception exception) {
			System.out.println(exception);
				result.put("operation_result", "fail");
		}
		return new ResponseEntity<List<DashboardDTO>>(dashList, HttpStatus.OK);

	}
	@RequestMapping(value = "/getConversationDetail/{conersationId}", method = RequestMethod.GET,produces="application/json")
	public  ResponseEntity<List<DashboardDTO>> getConversationDetails(@PathVariable("conersationId") String conersationId) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<DashboardDTO> dashList= dashboardService.findDetailedConversation(conersationId);
		try {
				result.put("operation_result", "success");
	result.put("response", dashList);
		} catch (Exception exception) {
			System.out.println(exception);
				result.put("operation_result", "fail");
		}
		return new ResponseEntity<List<DashboardDTO>>(dashList, HttpStatus.OK);

	}
	
	@RequestMapping(value = "/getFilters", method = RequestMethod.POST, produces = "application/json")
	public  ResponseEntity<Map<String,List<String>>>  getFilters(@RequestBody FormRequestDTO formRequestDTO) {
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String,List<String>> response	= dashboardService.getFiltersFromDate(formRequestDTO);
		try {
			result.put("operation_result", "success");
			result.put("response", response);
		} catch (Exception exception) {
			System.out.println(exception);
				result.put("operation_result", "fail");
		}
		return new ResponseEntity<Map<String,List<String>>>(response, HttpStatus.OK);
		
		
	}
	
	
	
	
	@RequestMapping(value = "/filterResult", method = RequestMethod.POST, produces = "application/json")
	public  ResponseEntity<List<DashboardDTO>>  filterResults(@RequestBody FormRequestDTO formRequestDTO) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<DashboardDTO> dashList= dashboardService.getFilteredResult(formRequestDTO);
		try {
			result.put("operation_result", "success");
			result.put("response", dashList);
		} catch (Exception exception) {
			System.out.println(exception);
				result.put("operation_result", "fail");
			
		}
		return new ResponseEntity<List<DashboardDTO>>(dashList, HttpStatus.OK);
		
		
	}
	
	


	
	

}
