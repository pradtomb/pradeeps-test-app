package com.afpva.botframework.dashboard.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.afpva.botframework.dashboard.model.ConversationSession;

public interface BotConversationLogRepository  extends JpaRepository <ConversationSession, Long>
{

 
	

	String GetFilterQuery = "SELECT "
	+  " conversationlog.userid, " 
	+  " conversationlog.intentname, " 
	+  " conversationlog.agentid,  "
	+  " conversationlog.requestsentiment " 
	+" FROM conversationsessionhandler, conversationlog" 
	+" WHERE conversationsessionhandler.id = CAST(conversationlog.conversationid AS INTEGER)" 
	+" AND date(conversationsessionhandler.createdtimestamp) >=?1  AND date(conversationsessionhandler.updatedtimestamp) <=?2";			
	@Query(value=GetFilterQuery,nativeQuery=true)
	public List<Object[]> getFiltersData(Date fromDate, Date toDate);
	
	String QuerySessionId = "SELECT " 
  +" conversationsessionhandler.id, "
  +" conversationlog.requesttimestamp, "
  +" conversationlog.responsetimestamp," 
  +" conversationlog.channelid," 
  +" conversationlog.intentname, "
  +" conversationlog.intentconfidence,"
  +" conversationlog.agentid,"
  +" conversationlog.conversationreq, "
  +" conversationlog.conversationres, "
  +" conversationlog.userid "
+" FROM "
  +" conversationlog, "
  +" conversationsessionhandler " 
+" WHERE "
  +" CAST(conversationlog.conversationid AS INTEGER) = conversationsessionhandler.id"
  +" AND conversationsessionhandler.id=?1 order by conversationlog.requesttimestamp";
  	@Query(value = QuerySessionId,nativeQuery = true) 
	public List<Object[]> getResultSession(long conversationSessionId);
	
	
	String QueryString = "SELECT " 
			  +" conversationsessionhandler.id, "
			  +" conversationsessionhandler.createdtimestamp, "
			  +" conversationsessionhandler.updatedtimestamp," 
			  +" conversationsessionhandler.requestchannel," 
			  +" conversationlog.intentname, "
			  +" conversationlog.intentconfidence,"
			  +" conversationlog.agentid "
			+" FROM "
			  +" conversationlog, "
			  +" conversationsessionhandler " 
			+" WHERE "
			  +" CAST(conversationlog.conversationid AS INTEGER)= conversationsessionhandler.id"
			  +" AND date(conversationsessionhandler.createdtimestamp) >=?1  AND date(conversationsessionhandler.updatedtimestamp) <=?2"
			  +" AND conversationlog.userid = conversationsessionhandler.userid  AND conversationsessionhandler.userid= ?3"
			  +" AND conversationlog.agentid= ?4 "
			  +" AND conversationlog.intentname= ?5 "
			  +" AND conversationlog.requestsentiment= ?6";
	@Query(value = QueryString,nativeQuery = true) 
	public List<Object[]> filteredResult(Date fromDate, Date toDate,String user,String agent,String intent,String sentiment);//String user,String intent,String sentiment
	
	
	//Named Param Query
	String QueryStringNamedParam = "SELECT " 
			 +" conversationsessionhandler.id, "
			  +" conversationsessionhandler.createdtimestamp, "
			  +" conversationsessionhandler.updatedtimestamp," 
			  +" conversationlog.channelid," 
			  +" conversationlog.intentname, "
			  +" conversationlog.intentconfidence,"
			  +" conversationlog.agentid ,"
			  +" conversationlog.conversationreq, "
			  +" conversationlog.conversationres ,"
			  +" conversationlog.userid," 
			  +" conversationlog.requestsentiment"
			+" FROM "
			  +" conversationlog, "
			  +" conversationsessionhandler " 
			+" WHERE "
			  +" CAST(conversationlog.conversationid AS INTEGER)= conversationsessionhandler.id"
			  +" AND date(conversationsessionhandler.createdtimestamp) >=?1  AND date(conversationsessionhandler.updatedtimestamp) <=?2";
			 /* +" AND conversationlog.userid = conversationsessionhandler.userid  AND conversationsessionhandler.userid= :user"
			  +" AND conversationlog.agentid= :agent"
			  +" AND conversationlog.intentname= :intent "
			  +" AND conversationlog.requestsentiment=:sentiment";*/
	@Query(value = QueryStringNamedParam,nativeQuery = true) 
	public List<Object[]> filteredResultParam(@Param("fromDate")Date fromDate,@Param("toDate") Date toDate/*,@Param("user")String user,
			@Param("agent")String agent,@Param("intent")String intent,@Param("sentiment")String sentiment*/);
	
	
	
	
}