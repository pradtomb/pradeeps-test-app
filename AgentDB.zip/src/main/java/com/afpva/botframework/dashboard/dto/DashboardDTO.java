package com.afpva.botframework.dashboard.dto;

import java.util.Date;
import java.util.List;

public class DashboardDTO {

	private String conversationId;
	private Date startTime;
	private Date endTime;
	private String duration;
	private String intents;
	private String agentTransfer;
	private String channel;
	private double intentconfidence;
	private String request;
	private String response;
	
	private String user;
	private String agent;
	private String sentiment;
	
	List<String> lstIntentConfidence ;
	
	public String getConversationId() {
		return conversationId;
	}
	public Date getStartTime() {
		return startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public String getDuration() {
		return duration;
	}
	public String getIntents() {
		return intents;
	}
	public String getAgentTransfer() {
		return agentTransfer;
	}
	public String getChannel() {
		return channel;
	}
	public double getIntentconfidence() {
		return intentconfidence;
	}
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public void setIntents(String intents) {
		this.intents = intents;
	}
	public void setAgentTransfer(String agentTransfer) {
		this.agentTransfer = agentTransfer;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public void setIntentconfidence(double intentconfidence) {
		this.intentconfidence = intentconfidence;
	}
	
	public String getRequest() {
		return request;
	}
	public String getResponse() {
		return response;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	
	public List<String> getLstIntentConfidence() {
		return lstIntentConfidence;
	}
	public void setLstIntentConfidence(List<String> lstIntentConfidence) {
		this.lstIntentConfidence = lstIntentConfidence;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getAgent() {
		return agent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	public String getSentiment() {
		return sentiment;
	}
	public void setSentiment(String sentiment) {
		this.sentiment = sentiment;
	}
	
	
	
	}
