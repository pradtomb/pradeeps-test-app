package com.afpva.botframework.dashboard.dto;

import java.util.List;

public class DashboardFiltersDTO {

	List<String> users;
	List<String> intents;
	List<String> agents;
	List<String> sentiment;
	
	public List<String> getUsers() {
		return users;
	}
	public void setUsers(List<String> users) {
		this.users = users;
	}
	public List<String> getIntents() {
		return intents;
	}
	public void setIntents(List<String> intents) {
		this.intents = intents;
	}
	public List<String> getAgents() {
		return agents;
	}
	public void setAgents(List<String> agents) {
		this.agents = agents;
	}
	public List<String> getSentiment() {
		return sentiment;
	}
	public void setSentiment(List<String> sentiment) {
		this.sentiment = sentiment;
	}
	
}
