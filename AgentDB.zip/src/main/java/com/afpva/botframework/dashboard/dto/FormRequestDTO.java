package com.afpva.botframework.dashboard.dto;

import java.util.Date;

public class FormRequestDTO {

	private Date startDate;	
	private Date endDate;
	private String user;
	private String intent;
	private String agent;
	private String sentiment;
	
	
	
	public Date getStartDate() {
		return startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public String getUser() {
		return user;
	}
	public String getIntent() {
		return intent;
	}
	public String getAgent() {
		return agent;
	}
	public String getSentiment() {
		return sentiment;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public void setIntent(String intent) {
		this.intent = intent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	public void setSentiment(String sentiment) {
		this.sentiment = sentiment;
	}

	
	
}
