package com.afpva.botframework.dashboard.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "conversationsessionhandler")
public class ConversationSession implements Serializable {

	private static final long serialVersionUID = -2135799291603780306L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private long id;

	

	@Column(name = "requestchannel")
	private String requestChannel;

	@Column(name = "clientthreadid")
	private String clientThreadID;

	@Column(name = "userid")
	private String userID;

	@Column(name = "sessionobject")
	private String sessionObject;

	@Column(name = "createdtimestamp")
	private Date createdTimestamp;

	@Column(name = "updatedtimestamp")
	private Date updatedTimestamp;

	
	/*@ManyToOne
	@JoinColumn(name = "clientthreadid",referencedColumnName="conversationid",insertable = false, updatable = false)
	private BotConversationLog botConversationLog;
	
	
	public BotConversationLog getBotConversationLog() {
		return botConversationLog;
	}

	public void setBotConversationLog(BotConversationLog botConversationLog) {
		this.botConversationLog = botConversationLog;
	}*/
	@OneToMany(mappedBy="conversationSession")
	private Set<ConversationLog> conversationLog;

	

	public Set<ConversationLog> getConversationLog() {
		return conversationLog;
	}

	public void setConversationLog(Set<ConversationLog> conversationLog) {
		this.conversationLog = conversationLog;
	}

	public ConversationSession() {
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the requestChannel
	 */
	public String getRequestChannel() {
		return requestChannel;
	}

	/**
	 * @param requestChannel
	 *            the requestChannel to set
	 */
	public void setRequestChannel(String requestChannel) {
		this.requestChannel = requestChannel;
	}

	/**
	 * @return the clientThreadID
	 */
	public String getClientThreadID() {
		return clientThreadID;
	}

	/**
	 * @param clientThreadID
	 *            the clientThreadID to set
	 */
	public void setClientThreadID(String clientThreadID) {
		this.clientThreadID = clientThreadID;
	}

	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * @param userID
	 *            the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * @return the sessionObject
	 */
	public String getSessionObject() {
		return sessionObject;
	}

	/**
	 * @param sessionObject
	 *            the sessionObject to set
	 */
	public void setSessionObject(String sessionObject) {
		this.sessionObject = sessionObject;
	}

	/**
	 * @return createdTimestamp
	 */
	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	/**
	 * @param createdtimestamp
	 */
	public void setCreatedtimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	/**
	 * @return updatedTimestamp
	 */
	public Date getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	/**
	 * @param updatedtimestamp
	 */
	public void setUpdatedTimestamp(Date updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

	/**
	 * @param requestChannel
	 * @param clientThreadID
	 * @param userID
	 * @param sessionObject
	 * @param createdtimestamp
	 * @param updatedtimestamp
	 */

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ConversationSession [id=" + id + ", requestChannel=" + requestChannel + ", clientThreadID="
				+ ", userID=" + userID + ", sessionObject=" + sessionObject + ", createdtimestamp="
				+ createdTimestamp + ", updatedtimestamp=" + updatedTimestamp + "]";
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public ConversationSession(String requestChannel, String userID, String sessionObject, Date createdTimestamp,
			Date updatedTimestamp,String clientThreadID, Set<ConversationLog> conversationLog) {
		super();
		this.requestChannel = requestChannel;
		this.userID = userID;
		this.sessionObject = sessionObject;
		this.createdTimestamp = createdTimestamp;
		this.updatedTimestamp = updatedTimestamp;
		this.clientThreadID = clientThreadID;
		this.conversationLog = conversationLog;
	}	

}
