package com.afpva.botframework.dashboard.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.afpva.botframework.dashboard.dao.BotConversationLogRepository;
import com.afpva.botframework.dashboard.dto.DashboardDTO;
import com.afpva.botframework.dashboard.dto.FormRequestDTO;
@Service
public class DashboardService {

	@Autowired
	BotConversationLogRepository dashBoardRepository;
	
	public List<DashboardDTO> findAll(String conversationSessionId)
	{
		//List<BotConversationLog> botconvlogList = new ArrayList<BotConversationLog>();
		List<DashboardDTO> dash_Dtolst = new ArrayList<>();
		List<DashboardDTO> dtoLst = new ArrayList<>();
		try {
			List<Object[]> sessionList =  new ArrayList<Object[]>();

		dashBoardRepository.getResultSession(Long.valueOf(conversationSessionId))
				.forEach(sessionList::add);
		List<String> lstIntentConfidence = new ArrayList<>();
		Set<String> sessionIdSet = new HashSet<String>();
		List<String> sessionIdLst = new ArrayList<>();
		
		
		for(Object[]  session :sessionList )
		{
			
			DashboardDTO dash_Dto = new DashboardDTO();
			
				sessionIdSet.add(session[0].toString());
				sessionIdLst.add(session[0].toString());
				dash_Dto.setConversationId(session[0].toString());
						
				Date fromDate = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS").parse(session[1].toString());
				Date todate = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS").parse(session[2].toString());
				dash_Dto.setStartTime(fromDate);
				dash_Dto.setEndTime(todate);
				dash_Dto.setChannel(session[3]==null?"":session[3].toString());
				dash_Dto.setDuration(timeDiff(session[1].toString(),session[2].toString()));
				dash_Dto.setIntents(session[4]==null?"":session[4].toString());
				double intentConfidence = Double.parseDouble(session[5]==null?"00.00":session[5].toString());
				
				//double confidence = Double.parseDouble(String.format("%.2f", 100*intentConfidence))*100;
				if(intentConfidence>0.0)
				{
				dash_Dto.setIntentconfidence(intentConfidence);
				}
				
				
				String isAgent = session[6]==null?"No":"Yes";
				dash_Dto.setAgentTransfer(isAgent);	
				
				dash_Dtolst.add(dash_Dto);
			}
			Iterator<String> iterator = sessionIdSet.iterator();
			int setSize = sessionIdSet.size();
			int listSize = dash_Dtolst.size();
			int datacount = 1;
			while (iterator.hasNext()) {
				String curSession = iterator.next().toString();
				//DashboardDTO DtoObj = new DashboardDTO();
				String intentsString = "";
				for (DashboardDTO dashboardDTO : dash_Dtolst) {

					if (curSession.equals(dashboardDTO.getConversationId())) {
						if(dashboardDTO.getIntents().length()>0)
						{
						lstIntentConfidence.add(
								
								intentsString + dashboardDTO.getIntents() + "~" + String.format("%.2f",100*dashboardDTO.getIntentconfidence())+"%");
						}

					} else {
						dashboardDTO.setLstIntentConfidence(lstIntentConfidence);
						dtoLst.add(dashboardDTO);
					}
					if (setSize == 1) {
						if (datacount == listSize) {
							dashboardDTO.setLstIntentConfidence(lstIntentConfidence);
							dtoLst.add(dashboardDTO);
						}
					}
					datacount++;
				}
			}

		} catch (ParseException ex) {
			ex.printStackTrace();
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}
		System.out.println(dtoLst.size());
		return dtoLst;
		
	}
	
	
	public List<DashboardDTO> findDetailedConversation(String conversationSessionId)
	{
		List<DashboardDTO> dash_Dtolst = new ArrayList<>();
		try 
		{
		List<Object[]> sessionList =  new ArrayList<Object[]>();
		dashBoardRepository.getResultSession(Long.valueOf(conversationSessionId))
				.forEach(sessionList::add);
		for(Object[]  session :sessionList )
		{
			
			DashboardDTO dash_Dto = new DashboardDTO();
				dash_Dto.setConversationId(session[0].toString());
				Date fromDate = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS").parse(session[1].toString());
				Date todate = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS").parse(session[2].toString());
				dash_Dto.setStartTime(fromDate);
				dash_Dto.setEndTime(todate);
				dash_Dto.setChannel(session[3]==null?"":session[3].toString());
				dash_Dto.setDuration(timeDiff(session[1].toString(),session[2].toString()));
				dash_Dto.setIntents(session[4]==null?"":session[4].toString());
			//	String intentConfDec= String.format("%.2f",session[5]==null?"0.0":session[5].toString());
				double intentConfidence = Double.parseDouble(session[5]==null?"00.00":session[5].toString());
				intentConfidence =intentConfidence*100;
				System.out.println(intentConfidence);
				if(intentConfidence>0.0)
				{
					
					dash_Dto.setIntentconfidence(Double.parseDouble(String.format("%.2f",intentConfidence)));
				
				}
				String isAgent = session[6]==null?"No":"Yes";
				dash_Dto.setRequest(session[7]==null?"":session[7].toString());
				dash_Dto.setResponse(session[8]==null?"":session[8].toString());
				dash_Dto.setAgentTransfer(isAgent);	
				dash_Dto.setAgent(session[6]==null?"":session[6].toString());
				dash_Dto.setUser(session[9]==null?"":session[9].toString());
				dash_Dtolst.add(dash_Dto);
			}
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	
		return dash_Dtolst;
		
	}
	
	
	
	public Map<String,List<String>>  getFiltersFromDate(FormRequestDTO formRequestDto)
	{
		Map<String,List<String>> responseMap = new HashMap<String,List<String>>();
		List<Object[]> responseObject=dashBoardRepository.getFiltersData(formRequestDto.getStartDate(),formRequestDto.getEndDate());
		List<String> intents = new ArrayList<String>();
		List<String> users = new ArrayList<String>();
		List<String> agents = new ArrayList<String>();
		List<String> sentiments = new ArrayList<String>();
		Set<String> intentsSet = new HashSet<String>();
		Set<String> usersSet = new HashSet<String>();
		Set<String> agentsSet = new HashSet<String>();
		Set<String> sentimentsSet = new HashSet<String>();
		usersSet.add("ALL");
		intentsSet.add("ALL");
		agentsSet.add("ALL");
		sentimentsSet.add("ALL");
		for(Object[] dataStr : responseObject )
		{
			usersSet.add((dataStr[0])==null?"ALL":dataStr[0].toString().length()==0?"ALL":(dataStr[0].toString().trim()));
			intentsSet.add((dataStr[1])==null?"ALL":dataStr[1].toString().length()==0?"ALL":(dataStr[1]).toString().trim());
			agentsSet.add(dataStr[2]==null?"ALL":dataStr[2].toString().length()==0?"ALL":dataStr[2].toString().trim());
			sentimentsSet.add((dataStr[3])==null?"ALL":dataStr[3].toString().length()==0?"ALL":dataStr[3].toString().trim());
		}
		/*if(usersSet.size()>0){usersSet.add("ALL");}
		if(intentsSet.size()>0){intentsSet.add("ALL");}
		if(agentsSet.size()>0){agentsSet.add("ALL");}
		if(sentimentsSet.size()>0){sentimentsSet.add("ALL");}*/
		intents.addAll(intentsSet);
		users.addAll(usersSet);
		agents.addAll(agentsSet);
		sentiments.addAll(sentimentsSet);
		
		
		responseMap.put("users", users);
		responseMap.put("intents", intents);
		responseMap.put("agents", agents);
		responseMap.put("sentiments", sentiments);
		
		return responseMap;
		
	}
	
	
	
	
	public List<DashboardDTO>  getFilteredResult(FormRequestDTO formRequestDto)
	{	
		System.out.println("DashboardService::getFilteredResult::");
		List<DashboardDTO> dtoLst = new ArrayList<>();
		List<DashboardDTO> dash_Dtolst = new ArrayList<>();
		List<DashboardDTO> ret_Dtolst = new ArrayList<>();
		try {
			
			Set<String> sessionIdSet = new HashSet<String>();
			List<String> sessionIdLst = new ArrayList<>();
		List<Object[]> responseObject = dashBoardRepository.filteredResultParam(formRequestDto.getStartDate(), formRequestDto.getEndDate());/*,formRequestDto.getUser(),formRequestDto.getAgent(),formRequestDto.getIntent(),formRequestDto.getSentiment());*///, formRequestDto.getIntent(), formRequestDto.getSentiment()
		for(Object[] dataStr : responseObject )
		{
			DashboardDTO dashDtoObj = new DashboardDTO(); 
			dashDtoObj.setConversationId(dataStr[0].toString());
			Date fromDate;
			sessionIdSet.add(dataStr[0].toString());
			sessionIdLst.add(dataStr[0].toString());
			fromDate = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS").parse(dataStr[1].toString());
			Date todate = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS").parse(dataStr[2].toString());

			dashDtoObj.setStartTime(fromDate);
			dashDtoObj.setEndTime(todate);
			dashDtoObj.setDuration(timeDiff(dataStr[1].toString(), dataStr[2].toString()));
			dashDtoObj.setChannel(dataStr[3]==null?"":dataStr[3].toString());
			dashDtoObj.setIntents(dataStr[4]==null?"":dataStr[4].toString());
		
			double intentConfidence = Double.parseDouble(dataStr[5]==null?"0.0":dataStr[5].toString());
				if(intentConfidence>0.0)
						dashDtoObj.setIntentconfidence(intentConfidence);
			
			String isAgent = dataStr[6]==null?"No":dataStr[6].toString().length()>1?"Yes":"No";
			dashDtoObj.setAgentTransfer(isAgent);
			dashDtoObj.setRequest(dataStr[7]==null?"":dataStr[7].toString());
			dashDtoObj.setResponse(dataStr[8]==null?"":dataStr[8].toString());
			dashDtoObj.setAgent((dataStr[6]==null?"":dataStr[6].toString().length()==0?"-":dataStr[6].toString()));
			dashDtoObj.setUser((dataStr[9]==null?"":dataStr[9].toString()));
			dashDtoObj.setSentiment((dataStr[10]==null?"":dataStr[10].toString()));
			System.out.println(dashDtoObj.getAgent());
			System.out.println(dashDtoObj.getSentiment());
			System.out.println(dashDtoObj.getIntents());
			System.out.println(dashDtoObj.getUser());
			dash_Dtolst.add(dashDtoObj);
			isAgent="";
		}
		
		System.out.println("dash_Dtolst::size"+dash_Dtolst.size());
		/////////////////////////////// Code To Combine result
		
	
		int listSize = dash_Dtolst.size();
	
		Iterator<String> iterator = sessionIdSet.iterator();
		while (iterator.hasNext()) {
			String curSession = iterator.next().toString();
			List<String> lstIntentConfidence = new ArrayList<>();
			for (DashboardDTO dashboardDTO : dash_Dtolst) {
				
				if(curSession.equals(dashboardDTO.getConversationId()) )
				{
					if(dashboardDTO.getIntents().length()>0)
					{
					lstIntentConfidence.add(dashboardDTO.getIntents()+"~"+String.format("%.2f", 100*dashboardDTO.getIntentconfidence())+"%");
					}
					dashboardDTO.setLstIntentConfidence(lstIntentConfidence);
					if(listSize==1)
					{
						dtoLst.add(dashboardDTO);
					}
				}
				else
				{
					dtoLst.add(dashboardDTO);
				}
			}
		}
		
		Iterator<String> iteratorNex = sessionIdSet.iterator();
		while (iteratorNex.hasNext()) {
			int countAdd=0;
			String curSession = iteratorNex.next().toString();
			for (DashboardDTO dashboardDTO : dtoLst) {
					if (curSession.equals(dashboardDTO.getConversationId())&&countAdd==0) 
					{
						countAdd++;
						ret_Dtolst.add(dashboardDTO);
					}
				}
			}

	} catch (Exception ex) {
		ex.printStackTrace();
	}
	System.out.println(ret_Dtolst.size());
	//return ret_Dtolst;
	return dash_Dtolst;
	
	}
	
	public String timeDiff(String startTime, String endTime)
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS");
		Date d1 = null;
		Date d2 = null;
		String resultString="";
		try {
			d1 = format.parse(startTime);
			d2 = format.parse(endTime);

			//in milliseconds
			long diff = d2.getTime() - d1.getTime();

			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			long diffDays = diff / (24 * 60 * 60 * 1000);

			resultString =diffDays + " days, "+diffHours + " hours, "+diffMinutes + " minutes," +diffSeconds + " seconds.";

		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultString;
	}
	
	
	
}
