

 AppUrl=[{
	 application: 'DashBoardByConvId',
		getAllURL:'http://localhost:9103/dashboard/getConversation',
     url_filterResult:'http://localhost:9103/dashboard/filterResult',
		url_ForFilters:'http://localhost:9103/dashboard/getFilters',
		getDetailurl:'http://localhost:9103/dashboard/getConversationDetail'
    },
	]
	

/* AppUrl=[{
	 application: 'DashBoardByConvId',
		getAllURL:'https://afpva-agent-dashboard.mybluemix.net/dashboard/getConversation',
     url_filterResult:'https://afpva-agent-dashboard.mybluemix.net/dashboard/filterResult',
		url_ForFilters:'https://afpva-agent-dashboard.mybluemix.net/dashboard/getFilters',
		getDetailurl:'https://afpva-agent-dashboard.mybluemix.net/dashboard/getConversationDetail'
    },
]
 */
function getValueByKey(key, AppUrl,appName) {
    var i, len = AppUrl.length;
    for (i = 0; i < len; i++) {
		
		   if (AppUrl[i] && AppUrl[i].hasOwnProperty(key) && AppUrl[i].application==appName) {
        	return AppUrl[i][key];
        }
    }
    return -1;
}