var app = angular.module('myapp', []);

	app.controller('myappcontroller', function($scope, $http) {
		$scope.actionLookupConfigs = []
		$scope.actionLookupConfigForm = {
			actionid : "",
			actionname : "",
			actionhandlerserviceendpointurl : ""
			
		};

		var url_getAllData=getValueByKey('getAllURL', AppUrl,'ActionLookup');
		var url_addData= getValueByKey('addDataURL', AppUrl,'ActionLookup') ;
		var url_DeleteData= getValueByKey('deleteDataURL', AppUrl,'ActionLookup') ;

		getActionLookupConfigDetails();
		function getActionLookupConfigDetails() {
			$http({
				method : 'GET',
				url : url_getAllData,
			}).then(function successCallback(response) {
				$scope.actionLookupConfigs = response.data;
			}, function errorCallback(response) {
				console.log(response.statusText);
			});
		}

		$scope.processActionLookupConfig = function() {
			$http({
				method : 'POST',
				url : url_addData,
				data : angular.toJson($scope.actionLookupConfigForm),
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then(getActionLookupConfigDetails(), clearForm())
			  .success(function(data){
				$scope.actionLookupConfigs= data
				getActionLookupConfigDetails();
		    });
		}
		$scope.editActionLookupConfig = function(actionLookupConfig) {
			$scope.actionLookupConfigForm.actionid =actionLookupConfig.actionid;
			$scope.actionLookupConfigForm.actionname =actionLookupConfig.actionname;
			$scope.actionLookupConfigForm.actionhandlerserviceendpointurl = actionLookupConfig.actionhandlerserviceendpointurl;
			disableName();
		}
		$scope.deleteLookupConfig  = function(actionLookupConfig) {
			$http({
				method : 'GET',
				url : url_DeleteData+actionLookupConfig.actionid,
				headers : {
					'Content-Type' : 'text/plain'
				}
			}).then(getActionLookupConfigDetails(), clearForm())
			  .success(function(data){
					alert('Deleted Intent Config for '+actionLookupConfig.actionname);
					getActionLookupConfigDetails();
			    });
		}

		function clearForm() {
			$scope.actionLookupConfigForm.actionname = "";
			$scope.actionLookupConfigForm.actionhandlerserviceendpointurl = "";
			

		}
		;
		function disableName() {

		}
	});