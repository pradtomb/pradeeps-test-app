var app = angular.module('myapp', []);

	app.controller('myappcontroller', function($scope, $http) {
		$scope.templateConfigs = []
		$scope.templateConfigForm = {
			templateId : "",
			templateName : "",
			templateJSON : ""
			
		};

		var url_getAllData=getValueByKey('getAllURL', AppUrl,'FormTemplate');
		var url_addData= getValueByKey('addDataURL', AppUrl,'FormTemplate') ;
		var url_DeleteData= getValueByKey('deleteDataURL', AppUrl,'FormTemplate') ;

		getTemplateDetails();
		function getTemplateDetails() {
			$http({
				method : 'GET',
				url : url_getAllData,
			}).then(function successCallback(response) {
				$scope.templateConfigs = response.data;
			}, function errorCallback(response) {
				console.log(response.statusText);
			});
		}

		$scope.processTemplateConfig = function() {
			$http({
				method : 'POST',
				url : url_addData,
				data : angular.toJson($scope.templateConfigForm),
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then(getTemplateDetails(), clearForm())
			  .success(function(data){
				$scope.templateConfigs= data
				getTemplateDetails();
		    });
		}
		$scope.editTemplateConfig = function(templateConfig) {
			$scope.templateConfigForm.templateId=templateConfig.templateId
			$scope.templateConfigForm.templateName =templateConfig.templateName;
			$scope.templateConfigForm.templateJSON = templateConfig.templateJSON;
			disableName();
		}
		$scope.deleteLookupConfig  = function(templateConfig) {
			$http({
				method : 'GET',
				url : url_DeleteData+templateConfig.templateId,
				headers : {
					'Content-Type' : 'text/plain'
				}
			}).then(getTemplateDetails(), clearForm())
			  .success(function(data){
					alert('Deleted Intent Config for '+templateConfig.templateName);
					getTemplateDetails();
			    });
		}

		function clearForm() {
			$scope.templateConfigForm.templateName = "";
			$scope.templateConfigForm.templateJSON = "";
	
		};
		function disableName() {
	
		}
	});