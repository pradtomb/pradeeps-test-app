var app = angular.module('myapp', []);
	app.config(['$httpProvider', function($httpProvider) {
        $httpProvider.defaults.useXDomain = true;
        delete $httpProvider.defaults.headers.common['X-Requested-With'];
    }
]);
	app.controller('myappcontroller', function($scope, $http) {
		$scope.intentConfigs = []
		$scope.intentConfigForm = {
			configId : "",
			intentName : "",
			enabled : "",
			intentDisplayText : "",
			intentWorkspace : ""
		};
		
		
		var url_getAllData=getValueByKey('getAllURL', AppUrl,'IntentConfig');
		var url_addData= getValueByKey('addDataURL', AppUrl,'IntentConfig') ;
		var url_DeleteData= getValueByKey('deleteDataURL', AppUrl,'IntentConfig') ;

		getIntentConfigDetails();
		function getIntentConfigDetails() {
			
		$http({
				method : 'GET',
				url :url_getAllData
			}).then(function successCallback(response) {
				$scope.intentConfigs = response.data;
			}, function errorCallback(response) {
				console.log(response.statusText);
			});
		}


		$scope.processIntentConfig = function() {
			$http({
				method : 'POST',
				url : url_addData,
				data : angular.toJson($scope.intentConfigForm),
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then(getIntentConfigDetails(), clearForm())
			  .success(function(data){
				$scope.intentConfigs= data
				getIntentConfigDetails();
		    });
			
		}
		 $scope.editIntentConfig = function(IntentConfig) {
			 
			$scope.intentConfigForm.configId =IntentConfig.configId;
			$scope.intentConfigForm.intentName = IntentConfig.intentName;
			$scope.intentConfigForm.enabled = IntentConfig.enabled;
			$scope.intentConfigForm.intentDisplayText = IntentConfig.intentDisplayText;
			$scope.intentConfigForm.intentWorkspace = IntentConfig.intentWorkspace;
			
			SelectElement(IntentConfig.enabled);
		} 

function SelectElement(valueToSelect)
{   
    var element = document.getElementById('enabled');
	var setIndex = 0;
    for (var i = 0; i < element.options.length; i++) {

		
    if (new String(element.options[i].text).valueOf() == new String(valueToSelect).valueOf()) 
		{
        setIndex = i;
        break;
		}
	}
	element.options[setIndex].selected =true;

}

		$scope.deleteIntentConfig = function(IntentConfig) {
			$http({
				method : 'GET',
				url : url_DeleteData+IntentConfig.configId,
				headers : {
					'Content-Type' : 'text/plain'
				}
			}).then(getIntentConfigDetails(), clearForm())
			  .success(function(data){
					alert('Deleted Intent Config for '+IntentConfig.intentName);
					getIntentConfigDetails();
			    });
				
			}

		function clearForm() {
			$scope.intentConfigForm.intentName = "";
			$scope.intentConfigForm.enabled = "";
			$scope.intentConfigForm.intentDisplayText = "";
			$scope.intentConfigForm.intentWorkspace = "";
		
		}
		;
		function disableName() {
		SelectElement(IntentConfig.enabled);
		}
	});