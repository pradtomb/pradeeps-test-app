

 AppUrl=[{
        application: 'DashBoardByConvId',
		getAllURL:'http://localhost:8080/dashboard/getConversation',
        url_filterResult:'http://localhost:8080/dashboard/filterResult'
    },
	]
	

function getValueByKey(key, AppUrl,appName) {
    var i, len = AppUrl.length;
    for (i = 0; i < len; i++) {
		
		   if (AppUrl[i] && AppUrl[i].hasOwnProperty(key) && AppUrl[i].application==appName) {
        	return AppUrl[i][key];
        }
    }
    return -1;
}