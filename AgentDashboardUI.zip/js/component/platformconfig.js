var app = angular.module('myapp', []);

	app.controller('myappcontroller', function($scope, $http) {
		$scope.platformLookupConfigs = []
		$scope.platformLookupConfigForm = {
			id : "",
			serviceOperationId : "",
			serviceOperationURI : ""
			
		};

		var url_getAllData=getValueByKey('getAllURL', AppUrl,'PlatFormConfig');
		var url_addData= getValueByKey('addDataURL', AppUrl,'PlatFormConfig') ;
		var url_DeleteData= getValueByKey('deleteDataURL', AppUrl,'PlatFormConfig') ;

		getLookupConfigDetails();
		function getLookupConfigDetails() {
			$http({
				method : 'GET',
				url : url_getAllData,
			}).then(function successCallback(response) {
				$scope.platformLookupConfigs = response.data;
			}, function errorCallback(response) {
				console.log(response.statusText);
			});
		}

		$scope.processLookupConfig = function() {
			$http({
				method : 'POST',
				url : url_addData,
				data : angular.toJson($scope.platformLookupConfigForm),
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then(getLookupConfigDetails(), clearForm())
			  .success(function(data){
				$scope.platformLookupConfigs= data
				getLookupConfigDetails();
		    });
		}
		$scope.editLookupConfig = function(lookupConfig) {
			$scope.platformLookupConfigForm.id=lookupConfig.id;
			$scope.platformLookupConfigForm.serviceOperationId =lookupConfig.serviceOperationId;
			$scope.platformLookupConfigForm.serviceOperationURI = lookupConfig.serviceOperationURI;
			disableName();
		}
		$scope.deleteLookupConfig  = function(lookupConfig) {
			
			$http({
				method : 'GET',
				url : url_DeleteData+lookupConfig.id,
				headers : {
					'Content-Type' : 'text/plain'
				}
			}).then(getLookupConfigDetails(), clearForm())
			  .success(function(data){
					alert('Deleted Intent Config for '+lookupConfig.serviceOperationId);
					getLookupConfigDetails();
			    });
		}

		function clearForm() {
			$scope.platformLookupConfigForm.serviceOperationId = "";
			$scope.platformLookupConfigForm.serviceOperationURI = "";
		
		};
		function disableName() {
		
		}
	});