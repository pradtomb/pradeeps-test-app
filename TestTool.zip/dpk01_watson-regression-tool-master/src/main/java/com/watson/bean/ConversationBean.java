package com.watson.bean;

import org.json.simple.JSONObject;

/**
 * Conversation object bean for mapping client request.
 *
 */
public class ConversationBean {
	String workspace;
	JSONObject context;
	String customerMessage;

	public String getWorkspace() {
		return workspace;
	}

	public void setWorkspace(String workspace) {
		this.workspace = workspace;
	}

	public JSONObject getContext() {
		return context;
	}

	public void setContext(JSONObject context) {
		this.context = context;
	}

	public String getCustomerMessage() {
		return customerMessage;
	}

	public void setCustomerMessage(String customerMessage) {
		this.customerMessage = customerMessage;
	}
}
