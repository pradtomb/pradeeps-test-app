package com.watson.constant;

/**
 * ENUM containing header information of regression file.
 *
 */
public enum RegressionFileHeader{
	StepNo(0),
	Repeat(1),
	RequestText(2),
	RequestParameter(3),
	ExpectedResponse(4),
	ExpectedResponseParameter(5),
	ActualResponse(6),
	ActualResponseParameter(7),
	Result(8),
	FailureReason(9);

    private final int value;

    RegressionFileHeader(final int newValue) {
        value = newValue;
    }

    public int getValue() { return value; }
}