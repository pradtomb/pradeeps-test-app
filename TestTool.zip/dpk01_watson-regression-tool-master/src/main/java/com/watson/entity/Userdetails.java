package com.watson.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="userlogin")
public class Userdetails implements Serializable{
	@Id @GeneratedValue
	@Column(name = "loginid")
	  long loginid ;
	  String userid ;
	  String password ;
	  String enviornmentname ;
	  String envusername ;
	  String envpassword ;
	  @OneToMany(mappedBy="userdetails")
	  private Set<Environment> enviornments ;
	  
	  public Userdetails(String userid, String password, String enviornmentname, String envusername, String envpassword ,Set<Environment> enviornments) {
		super();
		this.userid = userid;
		this.password = password;
		this.enviornmentname = enviornmentname;
		this.envusername = envusername;
		this.envpassword = envpassword;
		this.enviornments = enviornments;
	}
	  public Userdetails()
	  {}
	public long getLoginid() {
		return loginid;
	}
	public void setLoginid(long loginid) {
		this.loginid = loginid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEnviornmentname() {
		return enviornmentname;
	}
	public void setEnviornmentname(String enviornmentname) {
		this.enviornmentname = enviornmentname;
	}
	public String getEnvusername() {
		return envusername;
	}
	public void setEnvusername(String envusername) {
		this.envusername = envusername;
	}
	public String getEnvpassword() {
		return envpassword;
	}
	public void setEnvpassword(String envpassword) {
		this.envpassword = envpassword;
	}
	
	public Set<Environment> getEnviornments() {
		return enviornments;
	}
	
	public void setEnviornments(Set<Environment> enviornments) {
		this.enviornments = enviornments;
	}
	

}
