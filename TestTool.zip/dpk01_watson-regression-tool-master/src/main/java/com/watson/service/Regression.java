package com.watson.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.json.java.JSON;
import com.ibm.watson.developer_cloud.conversation.v1.ConversationService;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageRequest;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageResponse;
import com.ibm.watson.developer_cloud.http.HttpHeaders;
import com.watson.bean.ConversationBean;
import com.watson.bean.RegressionBean;
import com.watson.constant.RegressionConstants;

@Path("/regression")
public class Regression {
	
	private static final String SUMMARY = "Summary_";
	private static final String REGRESSION_SUMMARY = "_Regression_Summary_";

	/** This method is responsible for executing regression test suite.
	 * @param data
	 * @param request
	 * @return response Response
	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Response runRegression(String data, @Context HttpServletRequest request) {
		ObjectMapper mapper = new ObjectMapper();
		JSONObject summary = new JSONObject();
		JSONObject summaryResponse = new JSONObject();
		long startTime = System.nanoTime();
		long estimatedTime = 0; // Time taken for regression run.
		try {
			RegressionBean regressionBean = mapper.readValue(data, RegressionBean.class);
			java.nio.file.Path path = Paths.get(regressionBean.getRegressionPath());
			if (Files.exists(path)) {
				int rowNo = 0;
				XSSFWorkbook workbook = new XSSFWorkbook();
		        XSSFSheet sheet = workbook.createSheet("Summary");
		          //File Link
		          CreationHelper createHelper = workbook.getCreationHelper();
	    	      XSSFCellStyle hlinkstyle = workbook.createCellStyle();
	    	      XSSFFont hlinkfont = workbook.createFont();
	    	      hlinkfont.setUnderline(XSSFFont.U_SINGLE);
	    	      hlinkfont.setColor(HSSFColor.BLUE.index);
	    	      hlinkstyle.setFont(hlinkfont);
	    	      XSSFHyperlink link = (XSSFHyperlink)createHelper.createHyperlink(Hyperlink.LINK_FILE);
	    	      
		        createSummaryHeader(sheet, rowNo, workbook);
		        List<String> passWorkspace = new ArrayList<>();
		        List<String> failWorkspace = new ArrayList<>();
		        JSONArray worksapceSummary = new JSONArray();
				for (String workspace : regressionBean.getWorkspace()) {
					rowNo++;
					String useCase = workspace;
					String regressionPath = regressionBean.getRegressionPath() + File.separator + useCase;
					String workspaceId = getWorskpaceId(workspace);
					if (null == workspaceId) {
						//TODO:error handling
						continue;
					}
					File directory = new File(regressionPath);
					File[] files = directory.listFiles();
					if (null == files) {
						failWorkspace.add(workspace);
						summaryResponse.put(workspace, getDummyResponse(workspace, RegressionConstants.WORKSPACE_FOLDER_NOT_EXIST));
						worksapceSummary.add(getDummyWorksapceResponse(workspace, RegressionConstants.WORKSPACE_FOLDER_NOT_EXIST));
					} else if (null != files && files.length == 0) {
						failWorkspace.add(workspace);
						worksapceSummary.add(getDummyWorksapceResponse(workspace, RegressionConstants.WORKSPACE_FOLDER_IS_EMPTY));
						summaryResponse.put(workspace, getDummyResponse(workspace, RegressionConstants.WORKSPACE_FOLDER_IS_EMPTY));
					} else {
						JSONObject result = readFilesInDirectory(files, workspaceId, workspace, worksapceSummary);
						summaryResponse.put(workspace, result.get("result"));
						createSummaryCell(result, rowNo, workbook, link, hlinkstyle);
						passWorkspace.add(workspace);
					}
				}
				if (passWorkspace.size() > 0 ) {
					Date date = new Date();
					SimpleDateFormat dt = new SimpleDateFormat("yyyyddMMHHmmss"); 
					FileOutputStream fos =new FileOutputStream(new File(regressionBean.getRegressionPath() + File.separator + regressionBean.getService().toUpperCase() + REGRESSION_SUMMARY + dt.format(date) + ".xlsx"));
			        workbook.write(fos);
			        fos.close();
				}
		        workbook.close();
		        
				summary.put("result", "success");//result -- > status
				estimatedTime = System.nanoTime() - startTime;
				long timeTaken = TimeUnit.SECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS);
				summary.put("timeTaken", timeTaken);
				summary.put("summaryResponse", summaryResponse);
				summary.put("workspaceExecutionSummary", worksapceSummary);
			} else {
				summary.put("result", "fail");
				summary.put("data", RegressionConstants.REGRESSION_FOLDER_NOT_EXIST);
			}
		} catch (IOException | ParseException  e) {
			JSONObject error = new JSONObject();
			error.put("result", "error");
			error.put("data", e.getMessage());
			return Response.ok(error.toJSONString()).header("Content-Type", MediaType.APPLICATION_JSON).build();
		}
		return Response.ok(summary.toJSONString()).header("Content-Type", MediaType.APPLICATION_JSON).build();
	}
	
	/**
	 * This method is responsible for sending message to
	 * conversation service and get a response for user input.
	 * @param conversationBean
	 * @return response MessageResponse
	 */
	private MessageResponse sendConveration(ConversationBean conversationBean) {
		ConversationService service = new ConversationService("2017-02-03");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put(HttpHeaders.X_WATSON_LEARNING_OPT_OUT, "true");
		service.setDefaultHeaders(headers);
		service.setUsernameAndPassword(EnvironmentService.serviceCreadetials.get("userName"), EnvironmentService.serviceCreadetials.get("password"));
		MessageRequest newMessage = new MessageRequest.Builder()
				  .inputText(conversationBean.getCustomerMessage())
				  // Replace with the context obtained from the initial request
				  .context(conversationBean.getContext())
				  .build();
				MessageResponse response = service
				  .message(conversationBean.getWorkspace(), newMessage)
				  .execute();
				return  response;
	}
	
	/**
	 * This method is responsible for reading excel files from
	 * directory and executes regression suite 
	 * @param directoryName
	 * @param workSpaceId
	 * @param workspace
	 * @param worksapceSummary 
	 * @return regressiondetails JSONObject
	 * @throws IOException
	 * @throws ParseException
	 */
	private JSONObject readFilesInDirectory(File[] files, String workSpaceId, String workspace, JSONArray worksapceSummary) throws IOException, ParseException {
		System.out.println("workSpaceId" + workSpaceId);
		String conversationId = getConversationId(workSpaceId);
		JSONArray array = new JSONArray();
		Map<String, Object> regressionDetails = new HashMap<>();
		JSONObject result = new JSONObject();
		int fileSuccess = 0;
		List<String> filesFailReason = new ArrayList<>();
				for (File file : files) {
					if (file.getName().contains(SUMMARY)){
						continue;
					}
					regressionDetails.put("fileName", file.getName());
					FileInputStream fis = new FileInputStream(new File(file.getAbsolutePath()));
					XSSFWorkbook workbook = new XSSFWorkbook (fis);
					XSSFSheet sheet = workbook.getSheetAt(0);
					int passCount = 0;
					int totalRecords = sheet.getPhysicalNumberOfRows() -1 ;
					regressionDetails.put("totalRecords", totalRecords);
					Iterator ite = sheet.rowIterator();
					String regressionResult = "Fail";
					List<String> failReasonList = new  ArrayList<>();
					while(ite.hasNext()){
						Row row = (Row) ite.next();
						if(row.getRowNum()== 0){
							   continue; //just skip the rows if row number is 0 or 1
						}
						Cell cellRequestText = row.getCell(EnvironmentService.regressionFileHeader.get("Request Text"));
						String requestText = "";
						if (null != cellRequestText) {
							requestText = cellRequestText.getStringCellValue();
						}
						Cell cellRequestParameter = row.getCell(EnvironmentService.regressionFileHeader.get("Request Parameter"));
						String context = "";
						if(null != cellRequestParameter) {
							context = cellRequestParameter.getStringCellValue();
						}
						JSONParser parser = new JSONParser();
						JSONObject contextObj = (JSONObject) parser.parse(context);
						contextObj.put("conversation_id", conversationId);
						ConversationBean bean = new ConversationBean();
						bean.setContext(contextObj);
						bean.setWorkspace(workSpaceId);
						bean.setCustomerMessage(requestText);
						MessageResponse messageResponse = sendConveration(bean);
						
						//comparison start
						ObjectMapper om = new ObjectMapper();
						Cell cellExpectedResponse = row.getCell(EnvironmentService.regressionFileHeader.get("Expected Response"));
						String expctdResponse = "";
						if (null != cellExpectedResponse) {
							expctdResponse = cellExpectedResponse.getStringCellValue();
						}
						Cell cellExpectedResponseParam = row.getCell(EnvironmentService.regressionFileHeader.get("Expected Response Parameter"));
						String expctdResponseParam = "";
						if (null != cellExpectedResponseParam) {
							expctdResponseParam = cellExpectedResponseParam.getStringCellValue();
						}
						String actualResponse = "";
						if (messageResponse.getText().size() > 0) {
							actualResponse = messageResponse.getText().get(0);
						}
						Map<String, Object> expected = (Map<String, Object>)(om.readValue(expctdResponseParam, Map.class));
						boolean isContextSame = compareJson(expected, messageResponse.getContext());
						Cell Result = row.getCell(EnvironmentService.regressionFileHeader.get("Result"));
						if(null == Result) {//if blank cell value, then need to create cell instead of update
							Result = row.createCell(EnvironmentService.regressionFileHeader.get("Result"));
						}
						String failReason = "";
						if (expctdResponse.equalsIgnoreCase(actualResponse) && isContextSame) {
							Result.setCellValue("Pass");
							passCount++;
						} else {
							if (!expctdResponse.equalsIgnoreCase(actualResponse)) {
								Result.setCellValue("Fail");
								failReason = RegressionConstants.FAIL_TEXT;
							}
							if (!isContextSame) {
								Result.setCellValue("Fail");
								if (failReason.length() > 0) {
									failReason += ",";
						            }
								failReason += RegressionConstants.FAIL_CONTEXT;
							}
						}
						Cell cellFailureReason = row.getCell(EnvironmentService.regressionFileHeader.get("Failure Reason"));
						if(null == cellFailureReason) {
							cellFailureReason = row.createCell(EnvironmentService.regressionFileHeader.get("Failure Reason"));
						}
						cellFailureReason.setCellValue(failReason);
						Cell cellActualResponse = row.getCell(EnvironmentService.regressionFileHeader.get("Actual Response"));
						if(null == cellActualResponse) {
							cellActualResponse = row.createCell(EnvironmentService.regressionFileHeader.get("Actual Response"));
						}
						cellActualResponse.setCellValue(actualResponse);
						Cell cellActualResponseParameter = row.getCell(EnvironmentService.regressionFileHeader.get("Actual Response Parameter"));
						if(null == cellActualResponseParameter) {
							cellActualResponseParameter = row.createCell(EnvironmentService.regressionFileHeader.get("Actual Response Parameter"));
						}
						JSONObject jsonObject = new JSONObject(messageResponse.getContext());
						cellActualResponseParameter.setCellValue(jsonObject.toString());
						failReasonList.add(failReason);
					}
					if (totalRecords == passCount) {
						regressionResult = "Pass";
						fileSuccess += 1;
					}
					regressionDetails.put("result", regressionResult);
					regressionDetails.put("passCount", passCount);
					regressionDetails.put("useCase", workspace);
					String accuracy = getAccuracy(totalRecords, passCount);
					regressionDetails.put("accuracy", accuracy);
					String fileFailReason = getFileFailReason(failReasonList);
					regressionDetails.put("failReason", fileFailReason);
					fis.close();
					FileOutputStream fos =new FileOutputStream(new File(file.getAbsolutePath()));
			        workbook.write(fos);
			        fos.close();
			        workbook.close();
			        JSONObject object = new JSONObject(regressionDetails);
			        array.add(object);
			        filesFailReason.add(fileFailReason);
				}
				result.put("result", array);
				//workspce wise summary
				JSONObject workspaceJson = new JSONObject();
				workspaceJson.put("totalRecords", files.length);
				workspaceJson.put("result", files.length == fileSuccess ? RegressionConstants.PASS : RegressionConstants.FAIL);
				workspaceJson.put("passCount", fileSuccess);
				workspaceJson.put("useCase", workspace);
				workspaceJson.put("accuracy", getAccuracy(files.length, fileSuccess));
				workspaceJson.put("failReason", filesFailReason);
				worksapceSummary.add(workspaceJson);
				return result;
	}
	
	/**
	 * This method is responsible for returning conversation id.
	 * @param WorkSpaceId
	 * @return conversationId String
	 */
	private String getConversationId(String WorkSpaceId) {
		ConversationBean conversationBean = new ConversationBean();
		conversationBean.setWorkspace(WorkSpaceId);
		conversationBean.setCustomerMessage("");
		MessageResponse messageResponse = sendConveration(conversationBean);
		String conversationId = (String) messageResponse.getContext().get("conversation_id");
		return conversationId;
	}
	
	/**
	 * This method is responsible for comparing two JSON objects.
	 * @param sourceJson
	 * @param targetJson
	 * @return compare boolean
	 */
	private boolean compareJson(Map<String, Object> sourceJson, Map<String, Object> targetJson ) {
		sourceJson.remove("system");
		sourceJson.remove("conversation_id");
		targetJson.remove("system");
		targetJson.remove("conversation_id");
		convertFloatToInt(targetJson);
		boolean isSame = false;
        try {
            isSame = sourceJson.equals(targetJson);
        } catch (Exception e) {
        	isSame = false;
            e.printStackTrace();
        }
        return isSame;
	}
	
	/**
	 * This method is responsible for converting float values with .0 to integer.
	 * @param object
	 * @return object
	 */
	private Map<String, Object> convertFloatToInt(Map<String, Object> object) {
		for (String key : object.keySet()) {
			if (object.get(key) instanceof Map<?, ?>) {
				Map<String, Object> map = (Map<String, Object>) object.get(key);
				for (String prop : map.keySet()) {
					if (map.get(prop) instanceof Double) {
						Double d = (Double) map.get(prop);
						double fractionalPart = d % 1;
						if (fractionalPart == 0.0) {
							int value = d.intValue();
							map.put(prop, value);
						}
					}
				}
			}
		}
		return object;
	}
	
	/**
	 * This method is responsible for creating summary file header.
	 * @param sheet
	 * @param rowNo
	 * @param workbook 
	 */
	private void createSummaryHeader(XSSFSheet sheet, int rowNo, XSSFWorkbook workbook) {
		CellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.ORANGE.getIndex());
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setLeftBorderColor(IndexedColors.ORANGE.getIndex());
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.ORANGE.getIndex());
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.ORANGE.getIndex());
		Font font = workbook.createFont();
	    font.setColor(IndexedColors.WHITE.getIndex());
	    font.setBold(true);
	    style.setFont(font);
		Row headerRow = sheet.createRow(rowNo);
        Cell headerCell = headerRow.createCell(0);
        Cell headerCell1 = headerRow.createCell(1);
        Cell headerCell2 = headerRow.createCell(2);
        Cell headerCell3 = headerRow.createCell(3);
        Cell headerCell4 = headerRow.createCell(4);
        Cell headerCell5 = headerRow.createCell(5);
        Cell headerCell6 = headerRow.createCell(6);
        Cell headerCell7 = headerRow.createCell(7);
        headerCell.setCellValue("S No");
        headerCell.setCellStyle(style);
        headerCell1.setCellValue("Workspace");
        headerCell1.setCellStyle(style);
        headerCell2.setCellValue("File Name");
        headerCell2.setCellStyle(style);
        headerCell3.setCellValue("Total");
        headerCell3.setCellStyle(style);
        headerCell4.setCellValue("Pass");
        headerCell4.setCellStyle(style);
        headerCell5.setCellValue("Fail");
        headerCell5.setCellStyle(style);
        headerCell6.setCellValue("Accuracy");
        headerCell6.setCellStyle(style);
        headerCell7.setCellValue("Result");
        headerCell7.setCellStyle(style);
	}
	
	/**
	 * This method is responsible for creating summary file rows.
	 * @param jsonObject
	 * @param rowNo
	 * @param sheet
	 * @param hlinkstyle 
	 * @param link 
	 * @throws IOException
	 */
	private void createSummaryCell(JSONObject jsonObject, int rowNo,  XSSFWorkbook workbook, XSSFHyperlink link, XSSFCellStyle hlinkstyle) throws IOException {
		 XSSFSheet sheet = workbook.getSheet("Summary");
		JSONArray array = (JSONArray) jsonObject.get("result");
		for (int i = 0; i < array.size(); i++) {
			JSONObject cell = (JSONObject) array.get(i);
			Row row = sheet.createRow(rowNo);
	        String useCase = (String) cell.get("useCase");
	        String fileName = (String) cell.get("fileName");
	        int totalRecords = (Integer) cell.get("totalRecords");
	        int passCount = (Integer) cell.get("passCount");
	        String result = (String) cell.get("result");
	        int failCount = totalRecords - passCount;
	    	DecimalFormat df = new DecimalFormat();
	    	df.setMaximumFractionDigits(2);
	    	float percent = (passCount * 100.0f)/totalRecords;
	    	String accuracy = df.format(percent) + " %";
	    	CellStyle style = setXLSCellFont(workbook, "", false);
	        Cell cell0 = row.createCell(0);
	        cell0.setCellValue(rowNo);
	        cell0.setCellStyle(style);
	        Cell cell1 = row.createCell(1);
	        cell1.setCellValue(useCase);
	        cell1.setCellStyle(style);
	        Cell cell2 = row.createCell(2);
	        cell2.setCellValue(fileName);
	        //SET file link in xls
	        link.setAddress(useCase + "/" + fileName);
	        cell2.setHyperlink(link);
	        hlinkstyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	        hlinkstyle.setBottomBorderColor(IndexedColors.LIGHT_ORANGE.getIndex());
	        cell2.setCellStyle(hlinkstyle);
	        
	        Cell cell3 = row.createCell(3);
	        cell3.setCellValue(totalRecords);
	        cell3.setCellStyle(style);
	        Cell cell4 = row.createCell(4);
	        cell4.setCellValue(passCount);
	        cell4.setCellStyle(style);
	        Cell cell5 = row.createCell(5);
	        cell5.setCellValue(failCount);
	        cell5.setCellStyle(style);
	        Cell cell6 = row.createCell(6);
	        cell6.setCellValue(accuracy);
	        CellStyle accuracyStyle = setXLSCellFont(workbook, "", true);
	        cell6.setCellStyle(accuracyStyle);
	        Cell cell7 = row.createCell(7);
	        cell7.setCellValue(result);
	        CellStyle resultStyle = setXLSCellFont(workbook, result, false);
	        cell7.setCellStyle(resultStyle);
	        rowNo++;
		}
	}
	
	/**
	 * This method is responsible for retrieving workspace id.
	 * @param value
	 * @return workspaceId
	 */
	private String getWorskpaceId(String value) {
    	return EnvironmentService.workSpaceIds.get(value.toLowerCase()); 
    }
	
	/**
	 * This method is responsible for creating summary file header.
	 * @param sheet
	 * @param rowNo
	 * @param workbook 
	 */
	private CellStyle setXLSCellFont(XSSFWorkbook workbook, String result, boolean boldFont) {
		CellStyle style = workbook.createCellStyle();
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.LIGHT_ORANGE.getIndex());
		Font font = workbook.createFont();
		if (boldFont) {
			font.setBold(true);
		}
	    font.setColor(IndexedColors.BLACK.getIndex());
	    if ("Fail".equalsIgnoreCase(result)) {
	    	font.setColor(IndexedColors.RED.getIndex());
	    } else if ("Pass".equalsIgnoreCase(result)) {
	    	font.setColor(IndexedColors.GREEN.getIndex());
	    }
	    style.setFont(font);
		return style;
	}
	
	private String getAccuracy(int totalRecords, int passCount) {
    	DecimalFormat df = new DecimalFormat();
    	df.setMaximumFractionDigits(2);
    	float percent = (passCount * 100.0f)/totalRecords;
    	String accuracy = df.format(percent);
    	return accuracy;
	}
	
	private String getRegressionExecutionMessage(List<String> passWorksapce, List<String> failWprkspace) {
		String message = "";
		if (passWorksapce.size() > 0 && failWprkspace.size() == 0) {
			message = String.format(RegressionConstants.REGRESSION_SUCCESS, String.join(", ", passWorksapce));
		} else if (passWorksapce.size() > 0 && failWprkspace.size() >  0) {
			message = String.format(RegressionConstants.REGRESSION_PARTIAL,  String.join(", ", passWorksapce), String.join(", ", failWprkspace));
		} else if (passWorksapce.size() == 0 && failWprkspace.size() >  0) {
			message = String.format(RegressionConstants.REGRESSION_FAILED, String.join(", ", failWprkspace));
		}
		return message;
	}
	
	private JSONArray getDummyResponse(String workspace, String failReason) {
		JSONArray array = new JSONArray();
		JSONObject dummy = new JSONObject();
		dummy.put("totalRecords", 0);
		dummy.put("result", RegressionConstants.FAIL);
		dummy.put("passCount", 0);
		dummy.put("useCase", workspace);
		dummy.put("accuracy", "");
		dummy.put("failReason", failReason);
		dummy.put("fileName", "");
		array.add(dummy);
		return array;
	}
	
	private String getFileFailReason(List<String> failReasonList) {
		String message = "";
		if (failReasonList.size() > 0) {
			for (String reason : failReasonList) {
				String[] arrFail = reason.split(",");
				if (arrFail.length > 1) {
					message = RegressionConstants.REGRESSION_FAIL_BOTH;
				} else {
					if (reason.equalsIgnoreCase(RegressionConstants.FAIL_CONTEXT)) {
						message = RegressionConstants.REGRESSION_FAIL_CONTEXT;
					} if (reason.equalsIgnoreCase(RegressionConstants.FAIL_TEXT)) {
						message = RegressionConstants.REGRESSION_FAIL_TEXT;
					}
				}
			}
		}
		return message;
	}
	
	private JSONObject getDummyWorksapceResponse(String workspace, String failReason) {
		JSONObject dummy = new JSONObject();
		dummy.put("totalRecords", 0);
		dummy.put("result", RegressionConstants.FAIL);
		dummy.put("passCount", 0);
		dummy.put("useCase", workspace);
		dummy.put("accuracy", "0");
		dummy.put("failReason", failReason);
		return dummy;
	}
}
