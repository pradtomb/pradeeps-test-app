'use strict';

/**
 * @description : This is a directive service used for showing the spinner
 * # loader directive
 *
 */

myApp.directive('loader', ['$rootScope', function($rootScope) {
    return {
        restrict: 'E',
        templateUrl: './htmls/loader.html',
        link: function(scope) {
            scope.showLoader = false;
            scope.$on("show_loader", function( events, param ) {
                scope.showLoader = param;
                try {
                    $rootScope.safeApply();
                } catch (exception) {
                }
            });
        }
    };
}]);
