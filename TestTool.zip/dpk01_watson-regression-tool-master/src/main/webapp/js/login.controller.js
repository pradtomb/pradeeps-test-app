myApp.controller('LoginController', function($rootScope, $scope, $timeout, $window, $q, $http, $state) {
	$rootScope.$broadcast("show_loader", false);
	$scope.isError = false;
	
    /**
     * Function for validaing user
     */
    $scope.validateUser = function() {
        var header = {
            headers: {
                'Content-Type': 'application/json',
                'charset': 'UTF-8'
            }
        };
        // REST Call
        $http.post('./rest/login', JSON.stringify({
                "username": $scope.username,
                "password": $scope.password
            }), header)
            .success(function(data) {
            	if (data.validLogin == "true") {
            		sessionStorage['loggedInUser'] = $scope.username;
            		$scope.isError = false;
            		$state.go('app');
            	} else if (data.validLogin == "false") {
            		$scope.isError = true;
            	}
            	$rootScope.$broadcast("show_loader", false);
            }).error(function(error) {
                $rootScope.$broadcast("show_loader", false);
            });
    };
    
    angular.element(document).ready(function() {
    });
    $scope.setHeight = function() {
	    var windowHeight = $window.innerHeight;
	    $('.mainLogin').css({ 'height': 'calc(' + windowHeight + 'px - 56px)' });
		$('#container').css({ 'height': 'calc(' + windowHeight + 'px - 56px)' });
	  };
	 $timeout(function() {
	
	
		 $scope.setHeight();
	  
	  /*$(window).resize(function() {
	    setHeight();
	  });*/
	 });
});