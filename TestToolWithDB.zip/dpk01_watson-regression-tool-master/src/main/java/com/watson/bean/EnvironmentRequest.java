package com.watson.bean;

/**
 * Environment Request object bean for mapping client request.
 *
 */
public class EnvironmentRequest {
	String userName;
	String password;
	String environment;
	String path;
	String loggedinUser;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getLoggedinUser() {
		return loggedinUser;
	}
	public void setLoggedinUser(String loggedinUser) {
		this.loggedinUser = loggedinUser;
	}
}
