package com.watson.bean;

/**
 * Regression bean for mapping regression run request.
 *
 */
public class RegressionBean {
	String[] workspace;
	String regressionPath;
	String service;

	public String[] getWorkspace() {
		return workspace;
	}

	public void setWorkspace(String[] workspace) {
		this.workspace = workspace;
	}

	public String getRegressionPath() {
		return regressionPath;
	}

	public void setRegressionPath(String regressionPath) {
		this.regressionPath = regressionPath;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}
}
