package com.watson.constant;

public class RegressionConstants {

	public static final String REGRESSION_SUCCESS = "Regression completed successfully for %s";
	public static final String REGRESSION_PARTIAL = "Regression completed successfully for %s and failed for %s";
	public static final String REGRESSION_FAILED = "Regression failed for %s";
	public static final String REGRESSION_FOLDER_NOT_EXIST = "Regression folder not found";
	public static final String WORKSPACE_FOLDER_NOT_EXIST = "Workspace folder not found";
	public static final String WORKSPACE_FOLDER_IS_EMPTY = "Workspace folder is empty";
	public static final String FAIL = "Fail";
	public static final String PASS = "Pass";
	public static final String FAIL_TEXT = "Response Text";
	public static final String FAIL_CONTEXT = "Context";
	public static final String REGRESSION_FAIL_CONTEXT = "Regression fail because of context mismatch";
	public static final String REGRESSION_FAIL_TEXT = "Regression fail because of response text mismatch";
	public static final String REGRESSION_FAIL_BOTH = "Regression fail because of context and response text mismatch";
}
