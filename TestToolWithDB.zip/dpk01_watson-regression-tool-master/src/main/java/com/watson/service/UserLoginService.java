package com.watson.service;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.watson.dao.HibernateUtil;
import com.watson.entity.Environment;
import com.watson.entity.Userdetails;
 
public class UserLoginService {
 
    public static boolean authenticateUser(String userId, String password) {
    	Userdetails user = getUserByUserId(userId); 
    	if(user!=null && user.getUserid().equals(userId) && user.getPassword().equals(password)){
            return true;
        }else{
            return false;
        }
    }
    
    public static void updateUserDetails(String userId,String envUsername,String envUserPassword,String envName)
    {
    	Session session = HibernateUtil.openSession();
        Transaction tx = null;
        Userdetails user = getUserByUserId(userId);
        try {
            tx = session.getTransaction();
            tx.begin();
           // user =(Userdetails)session.get(Userdetails.class, userId); 
            user.setEnviornmentname(envName);
            user.setEnvpassword(envUserPassword);
            user.setEnvusername(envUsername);
            Environment env = new Environment(envName,envUsername,envUserPassword,user);
            Set<Environment> envSet = new HashSet<Environment>();
            envSet.add(env);
            user.setEnviornments(envSet);
            session.save(env);
            session.update(user); 
            //Query query = session.createQuery("from Userdetails where userid='"+userId+"'");
           // user = (Userdetails)query.uniqueResult();
           
            
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
    public static Userdetails getUserByUserId(String userId) {
        Session session = HibernateUtil.openSession();
        Transaction tx = null;
        Userdetails user = null;
        Set<Environment> envSet = null; 
        try {
            tx = session.getTransaction();
            tx.begin();
            System.out.println("from Userdetails where userid='"+userId+"'");
            Query query = session.createQuery("from Userdetails where userid='"+userId+"'");
            user = (Userdetails)query.uniqueResult();
            
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return user;
    }
}