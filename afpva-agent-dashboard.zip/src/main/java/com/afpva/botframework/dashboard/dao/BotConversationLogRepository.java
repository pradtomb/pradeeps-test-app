package com.afpva.botframework.dashboard.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.afpva.botframework.dashboard.model.BotConversationLog;

public interface BotConversationLogRepository  extends JpaRepository <BotConversationLog, Long>
{
	/*@Query("SELECT * FROM BotConversationLog BCL , ConversationSession CS  on BCL.conversationId=CS.clientThreadID AND BCL.conversationId LIKE %?1")
	List<BotConversationLog> findBySessionId(String sessionId);*/
	
	public List<BotConversationLog> findByConversationId(String conversationId);
}
