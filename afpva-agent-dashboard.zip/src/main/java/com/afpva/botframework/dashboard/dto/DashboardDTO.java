package com.afpva.botframework.dashboard.dto;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.OneToMany;

import com.afpva.botframework.dashboard.model.ConversationSession;

public class DashboardDTO {

	private String conversationId;
	public String getConversationId() {
		return conversationId;
	}
	public Date getStartTime() {
		return startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public String getDuration() {
		return duration;
	}
	public String getIntents() {
		return intents;
	}
	public String getAgentTransfer() {
		return agentTransfer;
	}
	public String getChannel() {
		return channel;
	}
	public double getIntentconfidence() {
		return intentconfidence;
	}
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public void setIntents(String intents) {
		this.intents = intents;
	}
	public void setAgentTransfer(String agentTransfer) {
		this.agentTransfer = agentTransfer;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public void setIntentconfidence(double intentconfidence) {
		this.intentconfidence = intentconfidence;
	}
	private Date startTime;
	private Date endTime;
	private String duration;
	private String intents;
	private String agentTransfer;
	private String channel;
	private double intentconfidence;
	
	
	
	
	}
