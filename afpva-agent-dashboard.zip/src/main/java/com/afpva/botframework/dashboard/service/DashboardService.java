package com.afpva.botframework.dashboard.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.afpva.botframework.dashboard.dao.BotConversationLogRepository;
import com.afpva.botframework.dashboard.dto.DashboardDTO;
import com.afpva.botframework.dashboard.model.BotConversationLog;
import com.afpva.botframework.dashboard.model.ConversationSession;

@Service
public class DashboardService {

	@Autowired
	BotConversationLogRepository dashBoardRepository;
	
	public List<DashboardDTO> findAll(String clientThreadId)
	{
		List<BotConversationLog> botconvlogList = new ArrayList<BotConversationLog>();
		
		dashBoardRepository.findByConversationId(clientThreadId)
		.forEach(botconvlogList::add);
		
		List<DashboardDTO> dash_Dtolst = new ArrayList<>();
	
		for(BotConversationLog botLog :botconvlogList)
		{
			
					
			Set<ConversationSession> sessionSet= botLog.getConveSessions();
			Iterator iterator = sessionSet.iterator(); 
			while (iterator.hasNext())
			{
				ConversationSession session = (ConversationSession) iterator.next();
				DashboardDTO dash_Dto = new DashboardDTO();
				dash_Dto.setConversationId(botLog.getConversationId());
				dash_Dto.setStartTime(botLog.getRequestTimestamp());
				dash_Dto.setEndTime(botLog.getResponseTimestamp());
				dash_Dto.setIntents(botLog.getIntentName());
				botLog.setChannelId(session.getRequestChannel());
				dash_Dto.setIntentconfidence(botLog.getIntentConfidence());
				dash_Dtolst.add(dash_Dto);
			
			}
			
			
		}
		
		
		
		
		return dash_Dtolst;
		
	
	}
	
	
}
