package com.afpva.botframework.dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AfpvaDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(AfpvaDashboardApplication.class, args);
	}
}
