package com.afpva.botframework.dashboard.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.afpva.botframework.dashboard.dto.DashboardDTO;
import com.afpva.botframework.dashboard.model.BotConversationLog;
import com.afpva.botframework.dashboard.model.ConversationSession;
import com.afpva.botframework.dashboard.service.DashboardService;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {
	@Autowired
	DashboardService dashboardService;
	
	
	
	
	@RequestMapping(value = "/getConversation", method = RequestMethod.GET,produces="application/json")
	public Map<String, Object> getConversation() {
		Map<String, Object> result = new HashMap<String, Object>();
		try {
			
			 dashboardService.findAll();
			/*List<DashboardDTO> dashList = new ArrayList<DashboardDTO>();
			DashboardDTO dashDto = new DashboardDTO();
			SessionDTO sessoinDto = new SessionDTO();
			Set<SessionDTO> sessoinDtoset = new HashSet<SessionDTO>();
			for(BotConversationLog bl : blogLst )
			{
				
				dashDto.setBotConversationMessageId(bl.getBotConversationMessageId());
				dashDto.setChannelId(bl.getChannelId());
				
				if(bl.getSessions().size()>0)
				{
					for(ConversationSession cs : bl.getSessions() )
					sessoinDto.setClientThreadID(cs.getClientThreadID());
					sessoinDtoset.add(sessoinDto);
				}
				dashDto.setSessions(sessoinDtoset);
			}*/
			
			
			
			
			
			
					
			result.put("operation_result", "success");
			result.put("response", "");
		} catch (Exception exception) {
			System.out.println(exception);
				result.put("operation_result", "fail");
			
		}
		return result;

	}
	
	

}
