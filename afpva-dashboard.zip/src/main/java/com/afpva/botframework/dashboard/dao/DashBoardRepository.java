package com.afpva.botframework.dashboard.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.afpva.botframework.dashboard.dto.DashboardDTO;
import com.afpva.botframework.dashboard.model.BotConversationLog;

public interface DashBoardRepository  extends JpaRepository <BotConversationLog, Long>
{
	@Query("SELECT * FROM BotConversationLog BCL , ConversationSession CS  on BCL.conversationId=CS.clientThreadID AND BCL.conversationId LIKE %?1")
	List<BotConversationLog> findBySessionId(String sessionId);
}
