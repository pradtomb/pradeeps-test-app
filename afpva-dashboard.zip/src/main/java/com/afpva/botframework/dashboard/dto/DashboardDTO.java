package com.afpva.botframework.dashboard.dto;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.OneToMany;

import com.afpva.botframework.dashboard.model.ConversationSession;

public class DashboardDTO {

	
	public String getConversationId() {
		return conversationId;
	}
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	public String getIntentName() {
		return intentName;
	}
	public void setIntentName(String intentName) {
		this.intentName = intentName;
	}
	public double getIntentConfidence() {
		return intentConfidence;
	}
	public void setIntentConfidence(double intentConfidence) {
		this.intentConfidence = intentConfidence;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getRequestTimestamp() {
		return requestTimestamp;
	}
	public void setRequestTimestamp(Date requestTimestamp) {
		this.requestTimestamp = requestTimestamp;
	}
	public Date getResponseTimestamp() {
		return responseTimestamp;
	}
	public void setResponseTimestamp(Date responseTimestamp) {
		this.responseTimestamp = responseTimestamp;
	}
	public String getRequestChannel() {
		return requestChannel;
	}
	public void setRequestChannel(String requestChannel) {
		this.requestChannel = requestChannel;
	}
	private String conversationId;
	private String intentName;
	private double	intentConfidence;
	private String userId;
	private Date requestTimestamp;
	private Date responseTimestamp;
	private String requestChannel;
}
