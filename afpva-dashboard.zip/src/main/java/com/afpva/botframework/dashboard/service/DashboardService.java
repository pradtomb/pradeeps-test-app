package com.afpva.botframework.dashboard.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.afpva.botframework.dashboard.dao.DashBoardRepository;
import com.afpva.botframework.dashboard.dto.DashboardDTO;
import com.afpva.botframework.dashboard.model.BotConversationLog;
import com.afpva.botframework.dashboard.model.ConversationSession;

@Service
public class DashboardService {

	@Autowired
	DashBoardRepository dashBoardRepository;
	
	public List<BotConversationLog> findAll()
	{
		List<BotConversationLog> botconvlogList = dashBoardRepository.findBySessionId("1");
		
		
		return botconvlogList;
	
	}
	
	
}
