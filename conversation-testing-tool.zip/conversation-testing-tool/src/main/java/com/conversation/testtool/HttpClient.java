package com.conversation.testtool;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.apache.poi.util.IOUtils;
public class HttpClient {

    public static void main(String args[]) throws IOException {
    	 try{
    		    String stringUrl = "https://gateway.watsonplatform.net/conversation/api/v1/workspaces?version=2017-02-03";
    	        URL url = new URL(stringUrl);
    	        URLConnection uc = url.openConnection();
    	        uc.setRequestProperty("X-Requested-With", "Curl");
    	        String userpass = "3e10dc8c-0947-444c-875c-a50652d0d099" + ":" + "rsLf34jZnivs";
    	        String basicAuth = "Basic " + new String(new Base64().encode(userpass.getBytes()));
    	        uc.setRequestProperty("Authorization", basicAuth);
    	        HttpClient hc = new HttpClient();
    	        String theString = hc.getStringFromInputStream(uc.getInputStream());


    			System.out.println("Done!"+theString);
    		   }
    		   catch(Exception ex)
    		   {
    			   ex.printStackTrace();
    		   }
    }
    
    
    
    private static String getStringFromInputStream(InputStream is) {

		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return sb.toString();

	}
    
    

    
}