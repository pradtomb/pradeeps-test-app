package com.watson.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;







import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.conversation.testtool.HttpClient;



public class EnvironmentService {
	
	
		
	public static Map<String, String> serviceCreadetials = new HashMap<>();
	public static Map<String, String> workSpaceIds = new HashMap<>();
	public static Map<String, Integer> regressionFileHeader = new HashMap<>();
	static {
		setRegressionFileHeader();
	}


	private static void setRegressionFileHeader() {
		regressionFileHeader.put("Step No", 0);
		regressionFileHeader.put("Repeat", 1);
		regressionFileHeader.put("Request Text", 2);
		regressionFileHeader.put("Request Parameter", 3);
		regressionFileHeader.put("Expected Response", 4);
		regressionFileHeader.put("Expected Response Parameter", 5);
		regressionFileHeader.put("Actual Response", 6);
		regressionFileHeader.put("Actual Response Parameter", 7);
		regressionFileHeader.put("Result", 8);
		regressionFileHeader.put("Failure Reason", 9);
	}
	
	
	/**
	 * This method is responsible for returning workspace list based on
	 * conversation service credentials.
	 * 
	 * @return workspacelist JSONArray
	 */
	public JSONArray getWorkspaceList(String stringUrl,String userid, String password) {
		//String url = "https://gateway.watsonplatform.net/conversation/api/v1/workspaces?version=2017-02-03";
		JSONArray workSpaceList = new JSONArray();
		try {
			//String stringUrl = "https://gateway.watsonplatform.net/conversation/api/v1/workspaces?version=2017-02-03";
	        URL url = new URL(stringUrl);
	        URLConnection uc = url.openConnection();
	        uc.setRequestProperty("X-Requested-With", "Curl");
	        String userpass = userid + ":" + password;
	        String basicAuth = "Basic " + new String(new Base64().encode(userpass.getBytes()));
	        uc.setRequestProperty("Authorization", basicAuth);
	        HttpClient hc = new HttpClient();
	        String theString = getStringFromInputStream(uc.getInputStream());
	        
			JSONParser jsonParser = new JSONParser();
			JSONObject list = (JSONObject) jsonParser.parse(theString);
			JSONArray array = (JSONArray) list.get("workspaces");
			for (int i = 0; i < array.size(); i++) {
				JSONObject jsonObject = (JSONObject) array.get(i);
				JSONObject workspace = new JSONObject();
				String workspaceName = (String) jsonObject.get("name");
				String workspaceId = (String) jsonObject.get("workspace_id");
				workspace.put("name", workspaceName);
				workspace.put("workspaceId", workspaceId);
				workSpaceIds.put(workspaceName.toLowerCase(), workspaceId);
				workSpaceList.add(workspace);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return workSpaceList;
	}
	
	
	private static String getStringFromInputStream(InputStream is) {

		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return sb.toString();

	}
}
