package com.watson.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="environment")
public class Environment implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="enviornmentid_seq")
    @SequenceGenerator(name="enviornmentid_seq", sequenceName="enviornmentid_seq", allocationSize=1)
	@Column(name = "enviornmentid")
	private long  enviornmentid ;
	private String enviornmentname ;
	private String envusername ;
	private String envpassword ;
	
	@ManyToOne
	@JoinColumn(name="loginid", nullable=false)
	private Userdetails userdetails;

	public Environment(){}
	
	public Environment(String enviornmentname, String envusername, String envpassword,Userdetails userdetails) {
		super();
		this.enviornmentname = enviornmentname;
		this.envusername = envusername;
		this.envpassword = envpassword;
		this.userdetails = userdetails;
	}

	public long getEnviornmentid() {
		return enviornmentid;
	}

	public void setEnviornmentid(long enviornmentid) {
		this.enviornmentid = enviornmentid;
	}

	public String getEnviornmentname() {
		return enviornmentname;
	}

	public void setEnviornmentname(String enviornmentname) {
		this.enviornmentname = enviornmentname;
	}

	public String getEnvusername() {
		return envusername;
	}

	public void setEnvusername(String envusername) {
		this.envusername = envusername;
	}

	public String getEnvpassword() {
		return envpassword;
	}

	public void setEnvpassword(String envpassword) {
		this.envpassword = envpassword;
	}

	public Userdetails getUserdetails() {
		return userdetails;
	}

	public void setUserdetails(Userdetails userdetails) {
		this.userdetails = userdetails;
	}
}
