package com.watson.service;

import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.watson.dao.HibernateUtil;
import com.watson.entity.Environment;
import com.watson.entity.Userdetails;

public class EnviornmentDataService {
	
	
	
	
	 public static List<Environment> getEnvByUserId(long userId) {
	        Session session = HibernateUtil.openSession();
	        Transaction tx = null;
	       
	        List<Environment> envList = null;
	        try {
	            tx = session.getTransaction();
	            tx.begin();
	           // System.out.println("from Environment where userid="+userId+"");
	            Query query = session.createQuery("from Environment where loginid="+userId+"");
	            envList = query.list();
	            
	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	        return envList;
	    }
	 
	 
	 public static void deleteEnvByUserId(long userId,String envName) {
	        Session session = HibernateUtil.openSession();
	        Transaction tx = null;
	       
	        List<Environment> envList = null;
	        try {
	            tx = session.getTransaction();
	            tx.begin();
	           // System.out.println("from Environment where userid="+userId+"");
	            Query query = session.createQuery("delete from Environment where loginid="+userId+" and enviornmentname='"+envName+"'");
	            int i  = query.executeUpdate();
	            
	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    
	    }

}
