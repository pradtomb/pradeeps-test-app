package com.watson.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.watson.bean.EnvironmentRequest;
import com.watson.entity.Environment;
import com.watson.entity.Userdetails;

@Path("/environment")
public class EnvironmentService {
	public static Map<String, String> serviceCreadetials = new HashMap<>();
	public static Map<String, String> workSpaceIds = new HashMap<>();
	public static Map<String, Integer> regressionFileHeader = new HashMap<>();
	static {
		setRegressionFileHeader();
	}

	/**
	 * This method is responsible for fetching environment as well as service
	 * credentials from environment JSON file.
	 * 
	 * @param request
	 * @return response Response
	 * @throws IOException
	 */
	@GET
	@Path("{loggedInUsre}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getEnvDetails(@PathParam("loggedInUsre") String loggedInUsre,@Context HttpServletRequest request) throws IOException {
		JSONObject jsonObject = new JSONObject();
		ObjectMapper mapper = new ObjectMapper();
		
		
		System.out.println("Logged In User"+loggedInUsre);
		Userdetails user = UserLoginService.getUserByUserId(loggedInUsre);
		long userid = user.getLoginid();
		List<Environment> envlist = EnviornmentDataService.getEnvByUserId(userid);
		System.out.println("Enviornment List"+envlist);
		
		try {
			//Map<String, JSONObject> envdetails = readEnvDetails(envlist); // Method that reades EnvDetails and return String as key and json objec
			
			//Map<String, JSONObject> envdetails = new JSONObject();
			 jsonObject = getEnviornmentJsonString(envlist);
			 String jsonText = jsonObject.toJSONString();
			 System.out.println("PreparedJsonObject is "+jsonText);
			
			
			 Map<String, JSONObject> envdetails = readEnvDetails(jsonText);
			
			
			
			
			
			
			System.out.println("EnvDetails"+envdetails);
			//Json Array That prepare enviornment List
			JSONArray envArray = new JSONArray();
			for (Map.Entry<String, JSONObject> entry : envdetails.entrySet()) {
				JSONObject envJson = new JSONObject();
				//if (entry.getKey().equalsIgnoreCase("dev")) 
				{
					String userName = (String) entry.getValue().get("user_name");
					String password = (String) entry.getValue().get("password");
					serviceCreadetials.put("userName", userName);
					serviceCreadetials.put("password", password);
				}
				envJson.put("name", entry.getKey().toUpperCase());
				envJson.put("value", entry.getKey());
				envJson.put("userName", entry.getValue().get("user_name"));
				envJson.put("password", entry.getValue().get("password"));
				envJson.put("defaultEnv", true);
				envArray.add(envJson);
			}
			//Json Array That prepares workspace List
			JSONArray workspaceList = new JSONArray();
			if (envdetails.size() > 0) {
				workspaceList = getWorkspaceList();	
			}
			jsonObject.put("result", "success");
			jsonObject.put("workspaceList", workspaceList);
			jsonObject.put("environment", envArray);
			return Response.ok(jsonObject.toJSONString()).header("Content-Type", MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			JSONObject error = new JSONObject();
			error.put("result", "fail");
			error.put("message", e.getMessage());
			return Response.serverError().entity(error.toJSONString())
					.header("Content-Type", MediaType.APPLICATION_JSON).build();
		}
	}

	/**
	 * This method is responsible for returning workspace list based on
	 * conversation service credentials.
	 * 
	 * @return workspacelist JSONArray
	 */
	private JSONArray getWorkspaceList() {
		String url = "https://gateway.watsonplatform.net/conversation/api/v1/workspaces?version=2017-02-03";
		JSONArray workSpaceList = new JSONArray();
		try {
			CredentialsProvider credsProvider = new BasicCredentialsProvider();
			credsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(
					serviceCreadetials.get("userName"), serviceCreadetials.get("password")));
			HttpClient httpClient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();
			HttpGet httpGet = new HttpGet(url);

			HttpResponse httpResponse = httpClient.execute(httpGet);
			HttpEntity responseEntity = httpResponse.getEntity();
			BufferedReader in = new BufferedReader(new InputStreamReader(responseEntity.getContent()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			JSONParser jsonParser = new JSONParser();
			JSONObject list = (JSONObject) jsonParser.parse(response.toString());
			JSONArray array = (JSONArray) list.get("workspaces");
			for (int i = 0; i < array.size(); i++) {
				JSONObject jsonObject = (JSONObject) array.get(i);
				JSONObject workspace = new JSONObject();
				String workspaceName = (String) jsonObject.get("name");
				String workspaceId = (String) jsonObject.get("workspace_id");
				workspace.put("name", workspaceName);
				workspace.put("workspaceId", workspaceId);
				workSpaceIds.put(workspaceName.toLowerCase(), workspaceId);
				workSpaceList.add(workspace);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(workSpaceList);
		return workSpaceList;
	}

	/**
	 * This method is responsible for reading environment json file.
	 * 
	 * @return envDetails {@link Map}
	 */
	//## Changed For Database Veresion ##
	/*private Map<String, JSONObject> readEnvDetails() {
		Map<String, JSONObject> envDetails = new JSONObject();
		FileReader fileReader = null;
		try {
			ClassLoader classLoader = getClass().getClassLoader();
			JSONParser parser = new JSONParser();
			fileReader = new FileReader(classLoader.getResource("environment.json").getFile());
			if(fileReader.read() > 0) {
				 
				String jsonText = " {\"dev\":{\"user_name\": \"532702ed-cf50-47fe-ad69-058d3685c58d\",\"password\":\"i3NZv1pil3Q8\"},\"sit\":{\"user_name\": \"abb79e3a-a2ba-4429-88aa-c65e1fc33380\",\"password\":\"luk8DY05Fchv\"}}";
				//Object obj = parser.parse(fileReader);
				Object obj = parser.parse(jsonText);
				JSONObject jsonObject = (JSONObject) obj;
				Iterator iterator = jsonObject.keySet().iterator();
				while (iterator.hasNext()) {
					String key = (String) iterator.next();
					if (jsonObject.get(key) instanceof JSONObject) {
						JSONObject object = (JSONObject) jsonObject.get(key);
						envDetails.put(key, object);
					}
				}
			}
			fileReader.close();
		} catch (IOException | ParseException ex) {
			if (null != fileReader) {
				try {
					fileReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			ex.printStackTrace();
		}
		return envDetails;
	}*/
	private JSONObject getEnviornmentJsonString(List<Environment> envlist)
	{
		String jsonString = "";
		 JSONObject responseDetailsJson = new JSONObject();
		 JSONArray jsonArrayReturnArray = new JSONArray();
		 //String jsonText = " {\"dev\":{\"user_name\": \"532702ed-cf50-47fe-ad69-058d3685c58d\",\"password\":\"i3NZv1pil3Q8\"},\"sit\":{\"user_name\": \"abb79e3a-a2ba-4429-88aa-c65e1fc33380\",\"password\":\"luk8DY05Fchv\"}}";
		for(Environment envobj : envlist)
		{
			 JSONArray jsonArray = new JSONArray();
			 JSONObject jsonNamePassObject = new JSONObject();
			 
			 
			 JSONObject enviornmentObject = new JSONObject();
			 
			envobj.getEnviornmentid();
			jsonNamePassObject.put("user_name",envobj.getEnvusername());
			jsonNamePassObject.put("password", envobj.getEnvpassword());
			
			
			responseDetailsJson.put(envobj.getEnviornmentname(), jsonNamePassObject);
			
			
		}
		return responseDetailsJson;
	}
	
	//## Changed For Database Veresion ##
		private Map<String, JSONObject> readEnvDetails(String jsonText) {
			Map<String, JSONObject> envDetails = new JSONObject();
			FileReader fileReader = null;
			try {
				ClassLoader classLoader = getClass().getClassLoader();
				JSONParser parser = new JSONParser();
				fileReader = new FileReader(classLoader.getResource("environment.json").getFile());
				if(fileReader.read() > 0) {
					 
					//String jsonText = " {\"dev\":{\"user_name\": \"532702ed-cf50-47fe-ad69-058d3685c58d\",\"password\":\"i3NZv1pil3Q8\"},\"sit\":{\"user_name\": \"abb79e3a-a2ba-4429-88aa-c65e1fc33380\",\"password\":\"luk8DY05Fchv\"}}";
					//Object obj = parser.parse(fileReader);
					Object obj = parser.parse(jsonText);
					JSONObject jsonObject = (JSONObject) obj;
					Iterator iterator = jsonObject.keySet().iterator();
					while (iterator.hasNext()) {
						String key = (String) iterator.next();
						if (jsonObject.get(key) instanceof JSONObject) {
							JSONObject object = (JSONObject) jsonObject.get(key);
							envDetails.put(key, object);
						}
					}
				}
				fileReader.close();
			} catch (IOException | ParseException ex) {
				if (null != fileReader) {
					try {
						fileReader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				ex.printStackTrace();
			}
			return envDetails;
		}

	/**
	 * This method is responsible for workspace on change of environment.
	 * 
	 * @param env
	 * @param request
	 * @throws IOException
	 */
	@POST
	@Path("updateenv")
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateEnv(String data, @Context HttpServletRequest request) throws IOException {
		JSONObject jsonObject = new JSONObject();
		try {
			ObjectMapper mapper = new ObjectMapper();
			EnvironmentRequest environmentRequest = mapper.readValue(data, EnvironmentRequest.class);
			serviceCreadetials.clear();
			System.out.println("Under Update ENV"+environmentRequest.getUserName());
			System.out.println("Under Update ENV"+environmentRequest.getPassword());
			
			
			serviceCreadetials.put("userName", environmentRequest.getUserName());
			serviceCreadetials.put("password", environmentRequest.getPassword());
			JSONArray workspaceList = getWorkspaceList();
			jsonObject.put("result", "success");
			jsonObject.put("workspaceList", workspaceList);
			return Response.ok(jsonObject.toJSONString()).header("Content-Type", MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			JSONObject error = new JSONObject();
			error.put("result", "fail");
			error.put("message", e.getMessage());
			return Response.serverError().entity(error.toJSONString())
					.header("Content-Type", MediaType.APPLICATION_JSON).build();
		}
	}
	
	
	@POST
	@Path("removeenv")
	@Produces(MediaType.APPLICATION_JSON)
	public Response removeEnv(String data, @Context HttpServletRequest request) throws IOException {
		JSONObject jsonObject = new JSONObject();
		try {
			ObjectMapper mapper = new ObjectMapper();
			EnvironmentRequest environmentRequest = mapper.readValue(data, EnvironmentRequest.class);
			serviceCreadetials.clear();
			String loggedInUsre= environmentRequest.getUserName();
			String envName=environmentRequest.getEnvironment();
			System.out.println("Under Update ENV"+environmentRequest.getUserName());
			
			System.out.println("Under Update ENV"+environmentRequest.getEnvironment());
			Userdetails user = UserLoginService.getUserByUserId(loggedInUsre);
			long userid = user.getLoginid();
			EnviornmentDataService.deleteEnvByUserId(userid, envName);
			//serviceCreadetials.put("userName", environmentRequest.getUserName());
			//serviceCreadetials.put("password", environmentRequest.getPassword());
			//JSONArray workspaceList = getWorkspaceList();
			jsonObject.put("result", "success");
			return Response.ok(jsonObject.toJSONString()).header("Content-Type", MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			JSONObject error = new JSONObject();
			error.put("result", "fail");
			error.put("message", e.getMessage());
			return Response.serverError().entity(error.toJSONString())
					.header("Content-Type", MediaType.APPLICATION_JSON).build();
		}
	}
	/**
	 * This method is responsible for adding new environment.
	 * 
	 * @param data
	 * @param request
	 * @throws IOException
	 */
	@POST
	@Path("addenv")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addEnv(String data, @Context HttpServletRequest request) throws IOException {
		JSONObject jsonObject = new JSONObject();
		try {
			ObjectMapper mapper = new ObjectMapper();
			EnvironmentRequest environmentRequest = mapper.readValue(data, EnvironmentRequest.class);
			serviceCreadetials.clear();
			
			serviceCreadetials.put("userName", environmentRequest.getUserName());
			serviceCreadetials.put("password", environmentRequest.getPassword());
			//System.out.println("Loggedin User"+environmentRequest.getLoggedinUser());
			System.out.println("Updating the User details with enviornment");
			UserLoginService.updateUserDetails(environmentRequest.getLoggedinUser(), environmentRequest.getUserName(), environmentRequest.getPassword(), environmentRequest.getEnvironment());
			
			JSONArray workspaceList = getWorkspaceList();
			jsonObject.put("result", "success");
			jsonObject.put("workspaceList", workspaceList);
			 //Call Update user database detailse
			return Response.ok(jsonObject.toJSONString()).header("Content-Type", MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			JSONObject error = new JSONObject();
			error.put("result", "fail");
			error.put("message", e.getMessage());
			return Response.serverError().entity(error.toJSONString())
					.header("Content-Type", MediaType.APPLICATION_JSON).build();
		}
	}
	
	
	/**
	 * This method is responsible for adding new environment.
	 * 
	 * @param data
	 * @param request
	 * @throws IOException
	 */
	@POST
	@Path("getEnv")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getEnv(String data, @Context HttpServletRequest request) throws IOException {
		JSONObject jsonObject = new JSONObject();
		try {
			ObjectMapper mapper = new ObjectMapper();
			EnvironmentRequest environmentRequest = mapper.readValue(data, EnvironmentRequest.class);
			serviceCreadetials.clear();
			serviceCreadetials.put("userName", environmentRequest.getUserName());
			serviceCreadetials.put("password", environmentRequest.getPassword());
			JSONArray workspaceList = getWorkspaceList();
			jsonObject.put("result", "success");
			jsonObject.put("workspaceList", workspaceList);
			return Response.ok(jsonObject.toJSONString()).header("Content-Type", MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			JSONObject error = new JSONObject();
			error.put("result", "fail");
			error.put("message", e.getMessage());
			return Response.serverError().entity(error.toJSONString())
					.header("Content-Type", MediaType.APPLICATION_JSON).build();
		}
	}
	
	
	@POST
	@Path("getExistingUserDetails")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getExistingEnv(String data, @Context HttpServletRequest request) throws IOException {
		JSONObject jsonObject = new JSONObject();
		try {
			ObjectMapper mapper = new ObjectMapper();
			EnvironmentRequest environmentRequest = mapper.readValue(data, EnvironmentRequest.class);
			serviceCreadetials.clear();

			Userdetails userDetails = UserLoginService.getUserByUserId(environmentRequest.getLoggedinUser());
			/*
			 * Commented for Load multiple Environment
			 * Set<Environment> envSet = userDetails.getEnviornments();
			
			JSONArray userworkspaceList = new JSONArray();
			System.out.println("Adding other details");
			if(envSet!=null)
			{
				Iterator iterator = envSet.iterator(); 
				while (iterator.hasNext()){
					Environment envObj = (Environment) iterator.next();
					
					JSONObject userworkspace = new JSONObject();
					userworkspace.put("workspaceName", envObj.getEnviornmentname());
					userworkspaceList.add(userworkspace);
					System.out.println("Adding other details"+envObj.getEnvusername());
					System.out.println("Adding other details"+envObj.getEnvpassword());
					serviceCreadetials.put("envName", envObj.getEnviornmentname());
					serviceCreadetials.put("userName", envObj.getEnvusername());
					serviceCreadetials.put("password", envObj.getEnvpassword());
					//serviceCreadetials.put("envName", userDetails.getEnviornmentname());
				}
			     
			}*/
			JSONArray userworkspaceList = new JSONArray();
			JSONObject userworkspace = new JSONObject();
			JSONObject userworkspace2 = new JSONObject();
			userworkspace.put("workspaceName","Env1");
			userworkspace2.put("workspaceName","Env2");
			userworkspaceList.add(userworkspace);
			userworkspaceList.add(userworkspace2);
			
			serviceCreadetials.put("userName", userDetails.getEnvusername());
			serviceCreadetials.put("password", userDetails.getEnvpassword());
			serviceCreadetials.put("envName", userDetails.getEnviornmentname());
			JSONArray workspaceList = getWorkspaceList();
			
		//	JSONArray userworkspaceList =
			
			
			jsonObject.put("result", "success");
			jsonObject.put("workspaceList", workspaceList);
			jsonObject.put("envText", userDetails.getEnviornmentname());
			jsonObject.put("userworkspaceList",userworkspaceList);
			return Response.ok(jsonObject.toJSONString()).header("Content-Type", MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			JSONObject error = new JSONObject();
			error.put("result", "fail");
			error.put("message", e.getMessage());
			return Response.serverError().entity(error.toJSONString())
					.header("Content-Type", MediaType.APPLICATION_JSON).build();
		}
	}
	/**
	 * This method is for storing regression file header sequence in a Map.
	 */
	private static void setRegressionFileHeader() {
		regressionFileHeader.put("Step No", 0);
		regressionFileHeader.put("Repeat", 1);
		regressionFileHeader.put("Request Text", 2);
		regressionFileHeader.put("Request Parameter", 3);
		regressionFileHeader.put("Expected Response", 4);
		regressionFileHeader.put("Expected Response Parameter", 5);
		regressionFileHeader.put("Actual Response", 6);
		regressionFileHeader.put("Actual Response Parameter", 7);
		regressionFileHeader.put("Result", 8);
		regressionFileHeader.put("Failure Reason", 9);
	}
}
