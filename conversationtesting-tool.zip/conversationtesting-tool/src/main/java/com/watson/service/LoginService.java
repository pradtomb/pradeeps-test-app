package com.watson.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.watson.bean.LoginRequest;

@Path("/login")
public class LoginService {

	private static final Logger Log = LoggerFactory.getLogger(LoginService.class);

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response validateLogin(String data, @Context HttpServletRequest request) {
		boolean flag = false;
		ObjectMapper mapper = new ObjectMapper();
		LoginRequest bean = null;
		JSONObject rootJson = new JSONObject();
		try {
			String users = System.getenv("users");
			System.out.println("user >>>>>>>>>>>>>>>>>>>>" + users);
			Map<String, String> userList = new HashMap<>();
			if (null != users) {
				ObjectMapper objectMapper = new ObjectMapper();
				userList = (Map<String, String>)(objectMapper.readValue(users, Map.class));
			}
			bean = mapper.readValue(data, LoginRequest.class);
			String userName = bean.getUsername();
			String passWord = bean.getPassword();
			String fileName = "user_credential.properties";
			Properties prop = loadPropertyFile(fileName);
			HttpSession session = request.getSession();
			
		//	System.out.println("Checking database user and password validations "+userName +","+passWord);
			 flag = UserLoginService.authenticateUser(userName, passWord);
			 System.out.println("First Login Test"+flag);
			//if (userList.size() > 0) {
			//	flag = validateUserCredentialsFromEnvVariables(userList, userName, passWord); //validate from system env
			//} else {
			//	flag = validateUserCredentialsFromFlatFile(prop, userName, passWord);
				//New Database method addded to validate user 
				
			     
			//}
			if (flag) {
				rootJson.put("username", userName);
				rootJson.put("validLogin", "true");
				session.setAttribute("userName", userName);
			} else {
				rootJson.put("validLogin", "false");
				rootJson.put("message", "Invalid credentials");
			}
		} catch (IOException e) {
			Log.error("", e);
			// e.printStackTrace();
			rootJson.put("validLogin", "false");
			rootJson.put("message", "Something went wrong");
		}

		return Response.ok(rootJson.toJSONString()).header("Content-Type", MediaType.APPLICATION_JSON).build();
	}

	private boolean validateUserCredentialsFromFlatFile(Properties prop, String username, String passWord) {
		boolean flag = false;
		String usernames = prop.getProperty("username");
		String passwords = prop.getProperty("password");
		String[] usernameArray = usernames.split(",");
		String[] passwordArray = passwords.split(",");
		for (String name : usernameArray) {
			if (name.trim().equals(username) && passwordArray[0].trim().equals(passWord)) {
				flag = true;
				break;
			}
		}
		return flag;
	}
	
	private boolean validateUserCredentialsFromEnvVariables(Map<String, String> userList, String username, String passWord) {
		boolean flag = false;
		String envPassword = userList.get(username);
		if (null != envPassword && envPassword.equals(passWord)) {
			flag = true;
		}
		return flag;
	}

	private Properties loadPropertyFile(String filePath) {
		InputStream inputStream = null;
		Properties prop = new Properties();
		try {
			inputStream = LoginService.class.getClassLoader().getResourceAsStream(filePath);
			if (inputStream == null) {
				throw new FileNotFoundException("Properties file not found");
			}
			prop.load(inputStream);
		} catch (FileNotFoundException cause) {
			Log.error("File  in getDataSource of WatsonRankRetrieveService - " + cause);
		} catch (IOException e) {
			Log.error("Error in loading Properties from  inputStream - " + e);
		} finally {
			try {
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (Exception cause) {
				Log.error("", cause);
				// cause.printStackTrace();
			}
		}
		return prop;
	}
}
