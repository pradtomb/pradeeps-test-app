myApp.controller('RegressionController', function($rootScope, $scope, $q, $http, dateFilter, ngDialog, $timeout, $state) {
	$rootScope.$broadcast("show_loader", false);
	
    // Conversation Service variables
	$scope.currentUser = sessionStorage['loggedInUser'];
    $scope.workspaceId = "";
    $scope.username = '';
    $scope.password = '';
    $scope.isTyping = false;
    $scope.selectedEnv = "";
    $scope.editselectedEnv = "";
    $scope.workspaceList = ""; 
    $scope.userEnvList = "";
    $scope.conversation = [];
    $scope.contextVariables;
    $scope.entities = [];
    $scope.intents = [];
    $scope.listContextVariables = {};
    $scope.selType = "impl"
    $scope.responseContext = {};
    $scope.requestContext = {};
    $scope.recordData = [];
    $scope.xlsCount = 0;
    $scope.context = {};
    $scope.regressionRunPath = "";
    $scope.contextInput = {
        name: '',
        value: ''
    }

    $scope.contextVars = {};
    $scope.customerMessage = "";

    // Boolean variables
    $scope.isRecording = false;
    $scope.isLoading = true;
    $scope.showDownloadLink = false;
    $scope.isRegressionComplete = false;
    $scope.messageRepeatFlag = false;
    $scope.fd = false;
    $scope.impl = false;

    $scope.conversationRecord = [];
    $scope.timerInterval = null;
    $scope.conversationContextImpl = {
        "common": {},
        "specific": {},
        "shared": {}
    }

    $scope.repeatContext = {};

    $scope.serviceCredentials = {
        serviceUserName: "",
        servicePassword: "",
        envName: "",
        regressionPath: "" 
    }

    $scope.regressionDetails = {
        regressionPath: ""
    }

    // Recorded file header column names
    $scope.xlsHeader = {
        headers: true,
        columns: [{
                columnid: 'Repeat',
                title: 'Repeat'
            },
            {
                columnid: 'RequestText',
                title: 'Request Text'
            },
            {
                columnid: 'RequestParameter',
                title: 'Request Parameter'
            },
            {
                columnid: 'ExpectedResponse',
                title: 'Expected Response'
            },
            {
                columnid: 'ExpectedResponseParameter',
                title: 'Expected Response Parameter'
            },
            {
                columnid: 'ActualResponse',
                title: 'Actual Response'
            },
            {
                columnid: 'ActualResponseParameter',
                title: 'Actual Response Parameter'
            },
            {
                columnid: 'Result',
                title: 'Result'
            }
        ],
    };

    // Summary file header column names
    $scope.xlsSummaryHeader = {
            headers: true,
            columns: [{
                    columnid: 'SNo',
                    title: 'S No'
                },
                {
                    columnid: 'Workspace',
                    title: 'Workspace'
                },
                {
                    columnid: 'FileName',
                    title: 'File Name'
                },
                {
                    columnid: 'Total',
                    title: 'Total'
                },
                {
                    columnid: 'Pass',
                    title: 'Pass'
                },
                {
                    columnid: 'Fail',
                    title: 'Fail'
                },
                {
                    columnid: 'Accuracy',
                    title: 'Accuracy'
                },
                {
                    columnid: 'Result',
                    title: 'Result'
                }
            ],
        };



    
    /**
     * Function to set/reset repeat flag;
     */
    $scope.setRepeatFlag = function($event) {
        //alert($event);
    };

    /**
     * Function for starting recording of chat messages for selected workspace.
     */
    $scope.startRecording = function() {
        if ($scope.isRecording) {
            $scope.isRecording = false;
            $scope.showDownloadLink = true;
        } else {
            $scope.isRecording = true;
        }
    };

    /**
     * Function for making a post call to Conversation for subsequent chat messages.
     */
    $scope.converse = function(isClear) {
    	var currentDate = new Date();
        if ($scope.customerMessage)
            $scope.conversation.push({
                "from": "customer",
                "text": $scope.customerMessage,
                "liclass": "right",
                "small": "",
                "strong": "pull-right",
                "spanicon": "pull-right",
                "chaticon": "userImage",
                "agent": "User",
                "time":currentDate
            });
        var chatDiv    = $('#inner-chat-window');
        var height = chatDiv[0].scrollHeight;
        $('#inner-chat-window').animate({scrollTop: height+200});
        delete $scope.contextVars[""]; //For removing empty context variables.
        $scope.conversationContextImpl = $scope.selType == "impl" ? Object.assign({}, $scope.conversationContextImpl) : {};
        $scope.contextVariables = $scope.selType == "fd" ? Object.assign({}, $scope.contextVars) : {};
        $scope.postMessage(isClear);
        /*var objDiv = document.getElementById("inner-chat-window");
        objDiv.scrollTop = objDiv.scrollHeight;*/
    };

    /**
     * Function for adding newly added context variables in the scope.
     */
    $scope.onBlurCtxVariable = function(key, newValue, subContext) {
        $scope.contextVars = $scope.selType == "fd" ? Object.assign({}, $scope.contextVars) : {};
        $scope.conversationContextImpl = $scope.selType == "impl" ? Object.assign({}, $scope.conversationContextImpl) : {};
        if ($scope.selType == "fd" && key.length > 0 && newValue.length > 0) { // Check if both key and values are added
            delete $scope.contextVars[""];
            $scope.contextVars = Object.assign({}, $scope.contextVars);
            $scope.contextVars[key] = newValue;
        } else if ($scope.selType == "impl" && subContext == "common" && key.length > 0 && newValue.length > 0) { // Check if both key and values are added
            delete $scope.conversationContextImpl["common"][""];
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
            $scope.conversationContextImpl["common"][key] = newValue;
        } else if ($scope.selType == "impl" && subContext == "specific" && key.length > 0 && newValue.length > 0) { // Check if both key and values are added
            delete $scope.conversationContextImpl["specific"][""];
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
            $scope.conversationContextImpl["specific"][key] = newValue;
        } else if ($scope.selType == "impl" && subContext == "shared" && key.length > 0 && newValue.length > 0) { // Check if both key and values are added
            delete $scope.conversationContextImpl["shared"][""];
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
            $scope.conversationContextImpl["shared"][key] = newValue;
        } else if ($scope.selType == "impl" && subContext == "default" && key.length > 0 && newValue.length > 0) { // Check if both key and values are added
        	delete $scope.conversationContextImpl[""];
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
            if(!isNaN(newValue)){$scope.conversationContextImpl[key] = parseInt(newValue, 10);}
            	else{ 
            		$scope.conversationContextImpl[key] = newValue;}
        }
        else if ($scope.selType == "impl" && subContext == "default" && key.length > 0 && newValue.length == 0) { // Check if both key and values are added
        	delete $scope.conversationContextImpl[""];
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
            $scope.conversationContextImpl[key] = "";
        }
        
    };

    /**
     * Function for adding blank text boxes on click of Add Variable icon. 
     */
    $scope.addContext = function(subContext) {
        if ($scope.selType == "fd") {
            $scope.contextVars[""] = "";
            $scope.contextVars = Object.assign({}, $scope.contextVars);
        } else if ($scope.selType == "impl" && subContext == "common") {
            $scope.conversationContextImpl["common"][""] = "";
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
        } else if ($scope.selType == "impl" && subContext == "specific") {
            $scope.conversationContextImpl["specific"][""] = "";
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
        } else if ($scope.selType == "impl" && subContext == "shared") {
            $scope.conversationContextImpl["shared"][""] = "";
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
        } else {
        	 $scope.conversationContextImpl[""] = "";
             $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
        }
    };

    /**
     * Function for sending chat message to Watson service.
     */
    $scope.submit = function(event) {
        if (event.keyCode == 13)
            $scope.converse();
    };

    /**
     * Function for deleting existing/newly added context variables.
     */
    $scope.deleteContext = function(key, subContext) {
        if ($scope.selType == "fd") {
            delete $scope.contextVars[key];
            $scope.contextVars = Object.assign({}, $scope.contextVars);
            $scope.contextInput.name = '';
            $scope.contextInput.value = '';
        } else if ($scope.selType == "impl" && subContext == "common") {
            delete $scope.conversationContextImpl["common"][key];
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
            $scope.contextInput.name = '';
            $scope.contextInput.value = '';
        } else if ($scope.selType == "impl" && subContext == "specific") {
            delete $scope.conversationContextImpl["specific"][key];
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
            $scope.contextInput.name = '';
            $scope.contextInput.value = '';
        } else if ($scope.selType == "impl" && subContext == "shared") {
            delete $scope.conversationContextImpl["shared"][key];
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
            $scope.contextInput.name = '';
            $scope.contextInput.value = '';
        } else {
        	delete $scope.conversationContextImpl[key];
            $scope.conversationContextImpl = Object.assign({}, $scope.conversationContextImpl);
            $scope.contextInput.name = '';
            $scope.contextInput.value = '';
        }
    };

    /**
     * Function for clearing conversation and emptying all required scope variables. 
     */
    $scope.clearConversation = function() {
    	$scope.resetConversation();
        $scope.converse(true);
    };
    
    /**
     * Function for resetting models
     */
    $scope.resetConversation = function() {
    	$("#chatView").show();
	    $("#regressionView").hide();
	    $(".outer-container").hide();
        $scope.conversation = [];
        $scope.context = {}
        $scope.contextVariables = {};
//        $scope.conversationContextImpl = {};
        $scope.conversationContextImpl = {
                "common": {},
                "specific": {},
                "shared": {}
            }
        $scope.contextVars = {};
        $scope.entities = [];
        $scope.intents = [];
        $scope.conversationRecord = [];
        $scope.isRecording = false;
        $scope.recordData = [];
        $scope.xlsCount = 0;
        $scope.messageRepeatFlag = false;
        $scope.customerMessage = "";
        $scope.showDownloadLink = false;
        $scope.regressionSummary = [];
        $scope.allWorkspaceExecutionSummary = [];
        $scope.selectedWSSummary = [];
        $scope.isTyping = false;
	};

    /**
     * Function for calling 'converse' REST service
     */
    $scope.postMessage = function(isClear) {
    	if (isClear) {
    		$rootScope.$broadcast("show_loader", true);
    	} else {
    		$scope.isTyping = true;
    	}
        var selectedWorkspaceId = "";
        if (typeof $scope.workspaceId == 'object' && $scope.workspaceId.length == 1) {
            selectedWorkspaceId = $scope.workspaceId[0].workspaceId;
        } else if (typeof $scope.workspaceId == 'object' && $scope.workspaceId.length > 1) {
        	$(".regression-success-msg").removeClass("alert-success");
        	$(".regression-success-msg").addClass("alert-danger");
            $(".regression-success-msg").text("Please select one workspace");
            $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
            $rootScope.$broadcast("show_loader", false);
            $scope.isTyping = false;
            return;
        }
        var context = "";
        if (!$scope.messageRepeatFlag) {
            context = $scope.selType == "fd" ? $scope.contextVars : $scope.conversationContextImpl;
            $scope.repeatContext = context;
        } else {
            context = $scope.repeatContext;
        }
        $scope.requestContext = context
        var header = {
            headers: {
                'Content-Type': 'application/json',
                'charset': 'UTF-8'
            }
        };
        // REST Call
        $http.post('./rest/conversation/converse', JSON.stringify({
                "workspace": selectedWorkspaceId,
                "customerMessage": $scope.customerMessage,
                "context": context
            }), header)
            .success(function(data) {
                var tempMessage = $scope.customerMessage;
                var tempReqContext = $scope.requestContext;
                var currentDate = new Date();
                if (data.output.text[0]) {
                    $scope.conversation.push({
                        "from": "watson",
                        "text": data.output.text,
                        "liclass": "left",
                        "small": "pull-right",
                        "strong": "",
                        "spanicon": "pull-left",
                        "chaticon": "botImage",
                        "agent":"Bot",
                        "time":currentDate
                    });
                }
                $scope.customerMessage = "";
                $scope.conversationContextImpl = $scope.selType == "impl" ? Object.assign({}, data.context) : {};
                $scope.contextVars = $scope.selType == "fd" ? data.context : {};
                console.log($scope.contextVars);
                $scope.responseContext = data.context;
                // two context - one to display one to edit
                $scope.contextVariables = data.context;
                if ($scope.isRecording)
                    $scope.conversationRecord.push($scope.createConversationRecord(tempMessage, tempReqContext, data.output.text, data.context));
                $rootScope.$broadcast("show_loader", false);
                $scope.isTyping = false;
                var chatDiv    = $('#inner-chat-window');
                var height = chatDiv[0].scrollHeight;
                $('#inner-chat-window').animate({scrollTop: height+200});
//                chatDiv.scrollTop(height);
            }).error(function(error) {
                console.log(error);
                $(".regression-success-msg").removeClass("alert-success");
            	$(".regression-success-msg").addClass("alert-danger");
                $(".regression-success-msg").text("Something went wrong");
                $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
                $rootScope.$broadcast("show_loader", false);
                $scope.isTyping = false;
            });
    };

    /**
     * Function for downloading recorded excel.
     */
    $scope.downloadXls = function() {
        var selectedWorkSpace = $("#workspaceDDN option:selected").html().replace(/ +/g, "");
        var selectedEnv =  $("#ddnEnvironment option:selected").html().replace(/ +/g, "");
        var currentDateTime = dateFilter(new Date(), 'yyyyddMMHHmmss');
        var fileName = selectedEnv + "_" + selectedWorkSpace + currentDateTime + ".xlsx";
        var date = new Date();
        if ($scope.conversationRecord.length > 0) {
        	//var fileName = fileName + "_" + selectedWorkSpace + currentDateTime + ".xlsx";
            alasql('SELECT [StepNo] AS [Step No], [Repeat] AS [Repeat], RequestText AS [Request Text], RequestParameter AS [Request Parameter], ExpectedResponse AS [Expected Response], ExpectedResponseParameter AS [Expected Response Parameter], ActualResponse AS [Actual Response], ActualResponseParameter AS [Actual Response Parameter], Result AS Result, FailureReason AS [Failure Reason] INTO XLSX("' + fileName + '",?) FROM ?', [$scope.xlsHeader, $scope.conversationRecord]);
        }
    };

    /**
     * Function for creating rows of recorded excel file
     */
    $scope.createConversationRecord = function(reqMessage, reqParam, actualResponseText, actualResponseParam) {
        delete reqParam['conversation_id'];
        delete actualResponseParam['conversation_id'];
        $scope.xlsCount = $scope.xlsCount + 1;
        var record = {
            StepNo: $scope.xlsCount,
            Repeat: '',
            RequestText: reqMessage,
            RequestParameter: JSON.stringify(reqParam),
            ExpectedResponse: actualResponseText,
            ExpectedResponseParameter: JSON.stringify(actualResponseParam),
            ActualResponse: '',
            ActualResponseParameter: '',
            Result: '',
            FailureReason: ''
        };
        return record;
    }

    /**
     * Function for regression run.
     */
    $scope.runRegression = function() {
    	$scope.backToWSSummaryView();
    	var arrSelectedWorkSpace = [];
        $("#workspaceDDN option:selected").each(function() {
            var selectedItem = $(this).text().replace(/ +/g, "");
            arrSelectedWorkSpace.push(selectedItem);
        });
    	if (arrSelectedWorkSpace.length == 0) {
    		$(".regression-success-msg").removeClass("alert-success");
        	$(".regression-success-msg").addClass("alert-danger");
            $(".regression-success-msg").text("Please select one workspace");
            $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
            $rootScope.$broadcast("show_loader", false);
            ngDialog.closeAll();
            return;
    	}
    	
        if ($scope.regressionRunPath.length == 0 && $scope.regressionDetails.regressionPath == "") {
            $scope.serviceErrorMessage = "Please enter path";
            $scope.pathErrorMessage = true;
            return;
        }
        $scope.isRegressionComplete = true;
        var header = {
            headers: {
                'Content-Type': 'application/json',
                'charset': 'UTF-8'
            }
        };
        // REST Call
        var path = $scope.regressionRunPath.length == 0 ? $scope.regressionDetails.regressionPath : $scope.regressionRunPath;
        ngDialog.closeAll();
        $("#chatView").hide();
        $("#regressionView").show();
        $("#rgressionCompleteMsg").hide();
        $("#reg-summary tbody").hide();
        $("html").addClass('bodyDisabled');
        $(".outer-container").show();
        var selectedEnv =  $("#ddnEnvironment option:selected").html().replace(/ +/g, "");
        $http.post('./rest/regression', JSON.stringify({
                "workspace": arrSelectedWorkSpace,
                "regressionPath": path,
                "service": selectedEnv
            }), header)
            .success(function(data) {
                if (data.result == "success") {
                    //ngDialog.closeAll();
                    $scope.regressionSummary = data["workspaceExecutionSummary"]; //summaryResponse
                    $scope.allWorkspaceExecutionSummary = data["summaryResponse"];
                    $(".regression-success-msg").removeClass("alert-danger");
                	$(".regression-success-msg").addClass("alert-success");
                    $(".regression-success-msg").text("Regression completed successfully in " + data.timeTaken + " seconds");
                    $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
                    $scope.isRegressionComplete = false;
                    $("html").removeClass('bodyDisabled');
                    $(".outer-container").hide();
                    $("#reg-summary tbody").show();
                    //$("#rgressionCompleteMsg span:first").text(data["workspaceExecutionSummary"] + ". Completed in " + data.timeTaken + " seconds");
                    //$("#rgressionCompleteMsg").show();
                } else if (data.result == "fail") {
                    $scope.serviceErrorMessage = data.data;
                    //$scope.pathErrorMessage = true;
                    $scope.isRegressionComplete = false;
                    $("html").removeClass('bodyDisabled');
                    $(".outer-container").hide();
                   // $("#rgressionCompleteMsg span:first").text($scope.serviceErrorMessage);
                    //$("#rgressionCompleteMsg").show();
                    $(".regression-success-msg").removeClass("alert-success");
                	$(".regression-success-msg").addClass("alert-danger");
                    $(".regression-success-msg").text($scope.serviceErrorMessage);
                    $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
                    $scope.regressionSummary = [];
                } else if (data.result == "error") {
                	$(".regression-success-msg").removeClass("alert-success");
                	$(".regression-success-msg").addClass("alert-danger");
                    $(".regression-success-msg").text("Something went wrong");
                    $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
                    $("html").removeClass('bodyDisabled');
                    $(".outer-container").hide();
                    $scope.regressionSummary = [];
                }
                //$("#outer-container").show();
            }).error(function(error) {
                //alert(error.result);
            })
    };
    
    /**
     * Function for fading away error/success messages
     */
    $scope.hideRegressionMessage = function() {
        $(".regression-success-msg").fadeOut("slow");
    }

    /**
     * Function creating rows of summary excel file.
     */
    $scope.regressionSummaryRecord = function(sNo, workspace, fileName, totalRecords, passCount, accuracy, result) {
        var record = {
            SNo: sNo,
            Workspace: workspace,
            FileName: fileName,
            Total: totalRecords,
            Pass: passCount,
            Fail: totalRecords - passCount,
            Accuracy: accuracy,
            Result: result
        };
        return record;
    };


    /**
     * Function for downloading regression summary file.
     */
    $scope.downloadSummary = function(fileData) {
        var downloadSummaryData =[];
        for (var i = 0; i < fileData.length; i++) {
                        var json = fileData[i];
                        downloadSummaryData.push($scope.regressionSummaryRecord(i+1, json.useCase, json.fileName, json.totalRecords, json.passCount, json.accuracy, json.result));
        }
		var selectedWorkSpace = "Regression_Summary_";
		var date = new Date();
		var currentDateTime = dateFilter(new Date(), 'yyyyddMMHHmmss');
		if (downloadSummaryData.length > 0) {
		    var fileName = selectedWorkSpace + currentDateTime + ".xlsx";
		    alasql('SELECT [SNo] AS [S No], [Workspace] AS [Workspace], FileName AS [File Name], Total AS [Total], Pass AS [Pass], Fail AS [Fail], Accuracy AS [Accuracy], Result AS [Result] INTO XLSX("' + fileName + '",?) FROM ?', [$scope.xlsSummaryHeader, downloadSummaryData]);
		}
    };

    
    /**
     * Function for displaying service credentials pop up. 
     */
    $scope.openServiceCredentials = function(eve) {
        ngDialog.open({
            template: 'htmls/add-service-popup.html',
            scope: $scope,
            className: 'ngdialog-theme-plain',
            preCloseCallback: function() {
            	$scope.serviceCredentials = {
            	        serviceUserName: "",
            	        servicePassword: "",
            	        envName: "",
            	        regressionPath: "" 
            	    }
            }
        });
    };
    
    /**
     * Function for displaying regression path pop up.
     */
    $scope.openRegressionPathPopup = function(eve) {
    	var arrSelectedWorkSpace = [];
        $("#workspaceDDN option:selected").each(function() {
            var selectedItem = $(this).text().replace(/ +/g, "");
            arrSelectedWorkSpace.push(selectedItem);
        });
    	if (arrSelectedWorkSpace.length == 0) {
    		$(".regression-success-msg").removeClass("alert-success");
        	$(".regression-success-msg").addClass("alert-danger");
            $(".regression-success-msg").text("Please select one workspace");
            $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
            $rootScope.$broadcast("show_loader", false);
            return;
    	}
    	if ($scope.regressionRunPath.length > 0) {
    		$("html").addClass('bodyDisabled');
    		$(".outer-container").show();
    		$scope.runRegression();
    	} else {
    		ngDialog.open({
                template: 'htmls/regression-run-popup.html',
                scope: $scope,
                className: 'ngdialog-theme-plain',
                preCloseCallback: function() {
                    $scope.pathErrorMessage = false;
                    $scope.regressionDetails.regressionPath = "";
                }
            });
    	}
    };

    /**
     * Function for retrieving Conversation service workspace list.
     */
    $scope.getWorkspaceList = function() {
    	$rootScope.$broadcast("show_loader", true);
        $http.get('./rest/environment/'+$scope.currentUser)
            .success(function(data) {
                if (data.result == "success") {
                    $scope.workspaceList = data.workspaceList;
                    $scope.environmentList = data.environment;
                    //The Data that retrive enviornment and datalist
                 
                   // alert("getWorkspaceList"+JSON.stringify(data));
                
                    console.log("workspaceList  " + $scope.workspaceList);
                    //$scope.workspaceId = [$scope.workspaceList[0]];
                    $scope.selectedEnv = $scope.environmentList.length > 0 ? $scope.environmentList[0].value : '';
                    $timeout(function() {
                    	$('#dvWorkspace + div').find("a").remove()
                    	$('#workspaceDDN').dropdown();
                    	$('#ddnEnvironment').dropdown();
                        //$('#workspaceDDN').dropdown('set selected', [$scope.workspaceList[0].name]);
					}); 
                }
                $rootScope.$broadcast("show_loader", false);
            }).error(function(error) {
            	$rootScope.$broadcast("show_loader", false);
            });
       
    }

    /**
     * Function for closing pop up.
     */
    $scope.cancel = function() {
        ngDialog.closeAll();
    };

    /**
     * Function for changing environment.
     */
    $scope.updateEnvDetails = function(envName) {
    	$rootScope.$broadcast("show_loader", true);
        var header = {
            headers: {
                'Content-Type': 'application/json',
                'charset': 'UTF-8'
            }
        };
        $scope.getWorkspaceList();
        var selctedEnvObject = $scope.environmentList.filter(function(el, index) {
            						return el.name.toLowerCase() == envName.toLowerCase();
        						})
        // REST Call
        						
							
        	
        $http.post('./rest/environment/updateenv', JSON.stringify({
        	"userName": selctedEnvObject[0].userName,
        	"password": selctedEnvObject[0].password,
        	"environment": selctedEnvObject[0].name}), header)
            .success(function(data) {
            	$scope.resetConversation();
                if (data.result == "success") {
                    $scope.workspaceList = data.workspaceList;
                    console.log("workspaceList  " + $scope.workspaceList);
                    //$scope.workspaceId = [$scope.workspaceList[0]];
                    $timeout(function() {
                    	$('#dvWorkspace + div').find("a").remove();
                    	$('#workspaceDDN').dropdown();
                    	$('#ddnEnvironment').dropdown();
                        //$('#workspaceDDN').dropdown('set selected', [$scope.workspaceList[0].name]);
					});
                }
                $rootScope.$broadcast("show_loader", false);
            }).error(function(error) {
            	$(".regression-success-msg").removeClass("alert-success");
            	$(".regression-success-msg").addClass("alert-danger");
                $(".regression-success-msg").text("Internal Server Error");
                $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
                $rootScope.$broadcast("show_loader", false);
            });
    };
    /**
     * Function for getting environment.
     */ 
    $scope.getEnvironment = function() {
    	
//alert("In get Enviornment");
var selEnv = $scope.serviceCredentials.envName;
var selUsername = $scope.serviceCredentials.serviceUserName;
var selPassword = $scope.serviceCredentials.servicePassword;
var selRegPath = $scope.serviceCredentials.regressionPath;
$rootScope.$broadcast("show_loader", true);
    	var header = {headers: {'Content-Type': 'application/json',
   	                'charset': 'UTF-8'}
   	        	};
   	 $http.post('./rest/environment/getExistingUserDetails' , JSON.stringify({
	        	"loggedinUser": $scope.currentUser}), header)
        .success(function(data) {
               if (data.result == "success") {
               	
               	ngDialog.closeAll();
               	$scope.resetConversation();
               	//Client side addition of new environment
               //	alert(JSON.stringify(data));
               	
               	$scope.selectedEnv = data.envText;
               	$scope.userEnvList = data.userworkspaceList;
            	   $scope.environmentList.push({name: selEnv.toUpperCase(), value: $scope.serviceCredentials.envName, userName: selUsername , password: selPassword});
               	   //$scope.environmentList.push({name: $scope.selectedEnv, value: $scope.serviceCredentials.envName, userName: selUsername , password: selPassword});
               	
                   $scope.selectedEnv = $scope.environmentList.length > 0 ? $scope.environmentList[$scope.environmentList.length - 1].value : '';
                   $scope.workspaceList = data.workspaceList;
                   //$scope.workspaceId = [$scope.workspaceList[0]];
                   
                   $scope.regressionRunPath = $scope.serviceCredentials.regressionPath;
                   $timeout(function() {
                   	$('#dvWorkspace + div').find("a").remove();
                   	$('#workspaceDDN').dropdown();
                   	$('#ddnEnvironment').dropdown();
                   	$('#ddnEnvironment').dropdown('set selected', [$scope.environmentList[$scope.environmentList.length - 1].name]);
                   	//$('#workspaceDDN').dropdown('set selected', [$scope.workspaceList[0].name]);
					});
               }
               $rootScope.$broadcast("show_loader", false);
               $(".regression-success-msg").removeClass("alert-danger");
               $(".regression-success-msg").addClass("alert-success");
               $(".regression-success-msg").text("Service added successfully");
               $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
               
           }).error(function(error) {
           	$(".regression-success-msg").removeClass("alert-success");
        	$(".regression-success-msg").addClass("alert-danger");
            $(".regression-success-msg").text("Internal Server Error");
            $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
            $rootScope.$broadcast("show_loader", false);
        });
   	 $scope.getWorkspaceList(); 
   };
   /**
    * Function to remove environment
    * 
    * */
   $scope.removeEnvironment = function(enviornmentName)
   {
	   
	   
	   $rootScope.$broadcast("show_loader", true);
       var header = {
           headers: {
               'Content-Type': 'application/json',
               'charset': 'UTF-8'
           }
       };
       // REST Call
       $http.post('./rest/environment/removeenv' , JSON.stringify({
	        	"userName": $scope.currentUser,
	        	"environment": enviornmentName
	        	}), header)
           .success(function(data) {
        	   $scope.getWorkspaceList();
   });
   };
    
    /**
     * Function for adding environment.
     */
    $scope.addEnvironment = function() {
    	var selEnv = $scope.serviceCredentials.envName;
    	var selUsername = $scope.serviceCredentials.serviceUserName;
    	var selPassword = $scope.serviceCredentials.servicePassword;
    	var selRegPath = $scope.serviceCredentials.regressionPath;
    	$rootScope.$broadcast("show_loader", true);
        var header = {
            headers: {
                'Content-Type': 'application/json',
                'charset': 'UTF-8'
            }
        };
        // REST Call
        $http.post('./rest/environment/addenv' , JSON.stringify({
	        	"userName": $scope.serviceCredentials.serviceUserName,
	        	"password": $scope.serviceCredentials.servicePassword,
	        	"environment": $scope.serviceCredentials.envName,
	        	"path": $scope.serviceCredentials.regressionPath,
	        	"loggedinUser": $scope.currentUser}), header)
            .success(function(data) {
                if (data.result == "success") {
                	
                	ngDialog.closeAll();
                	$scope.resetConversation();
                	//Client side addition of new environment
                	
                	$scope.environmentList.push({name: selEnv.toUpperCase(), value: $scope.serviceCredentials.envName, userName: selUsername , password: selPassword});
                    $scope.selectedEnv = $scope.environmentList.length > 0 ? $scope.environmentList[$scope.environmentList.length - 1].value : '';
                    $scope.workspaceList = data.workspaceList;
                    //$scope.workspaceId = [$scope.workspaceList[0]];
                    $scope.regressionRunPath = $scope.serviceCredentials.regressionPath;
                    $timeout(function() {
                    	$('#dvWorkspace + div').find("a").remove();
                    	$('#workspaceDDN').dropdown();
                    	$('#ddnEnvironment').dropdown();
                    	$('#ddnEnvironment').dropdown('set selected', [$scope.environmentList[$scope.environmentList.length - 1].name]);
                    	//$('#workspaceDDN').dropdown('set selected', [$scope.workspaceList[0].name]);
					});
                }
                $rootScope.$broadcast("show_loader", false);
                $(".regression-success-msg").removeClass("alert-danger");
                $(".regression-success-msg").addClass("alert-success");
                $(".regression-success-msg").text("Service added successfully");
                $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
                
            }).error(function(error) {
            	$(".regression-success-msg").removeClass("alert-success");
            	$(".regression-success-msg").addClass("alert-danger");
                $(".regression-success-msg").text("Internal Server Error");
                $(".regression-success-msg").slideDown("slow").delay(5000).fadeOut('slow');
                $rootScope.$broadcast("show_loader", false);
            });
    };
    
    $scope.openRequestResponse = function(eve) {
        ngDialog.open({
            template: 'htmls/request-response-json-viewer.html',
            scope: $scope,
            className: 'ngdialog-theme-plain',
            preCloseCallback: function() {
            }
        });
    };
    
    $rootScope.$on('ngDialog.opened', function (e, $dialog) {
      //$("#jsonView").JSONView($scope.requestContext);
      $("#jsonRequestView").JSONView($scope.requestContext);
      $("#jsonResponseView").JSONView($scope.responseContext);
    });

   /* $scope.responseJsonView = function () {
    	 $("#jsonView").JSONView($scope.responseContext);
    }
    
    $scope.requestJsonView = function () {
   	 $("#jsonView").JSONView($scope.requestContext);
   }*/
    $scope.logout = function() {
    	sessionStorage.clear();
    	$scope = undefined;
		$state.go('login');
	};
	
	$scope.closeRgressionCompleteMsg = function () {
		$("#rgressionCompleteMsg").hide();
	};
	
	$scope.displayWorkspaceSummary = function(workspace) {
		$scope.selWsName = workspace;
		$("#allWSDetails").hide();
		$("#selWSdetails").show();
		$scope.selectedWSSummary = $scope.allWorkspaceExecutionSummary[workspace]; 
		console.log($scope.allWorkspaceExecutionSummary[workspace]); 
	}
	$scope.backToWSSummaryView = function() {
		$("#selWSdetails").hide();
		$("#allWSDetails").show();
		$scope.selectedWSSummary = [];
	};
	
	/**
     * Function for opening about popup. 
     */
    $scope.openAboutPopup = function() {
    	$("#notificationContainer").hide();
        ngDialog.open({
            template: 'htmls/about-tool.html',
            scope: $scope,
            className: 'ngdialog-theme-plain',
            preCloseCallback: function() {
            	
            }
        });
    };
    
    /**
     * Function for opening view service details popup. 
     */
    $scope.openViewServiceDetailsPopup = function() {
    	//$("#notificationContainer").hide();
       ngDialog.open({
            template: 'htmls/view-environment-details.html',
            scope: $scope,
            className: 'ngdialog-theme-plain',
            preCloseCallback: function() {
            	
            }
        });
    };
	
    angular.element(document).ready(function() {
    	$('[data-toggle="tooltip1"]').tooltip({
            placement : 'bottom'
        });
    	
    	$( "#environmentOption" ).hover(
    			  function() {
    			    $("#notificationContainer").show();
    			  }, function() {
    				  //$("#notificationContainer").hide();
    	});
    	
    	$( "#logout" ).hover(
    			  function() {
    			    $("#notificationContainer").hide();
    			  }, function() {
    				$("#notificationContainer").hide();
    	});
    	
    	$( "#notificationContainer" ).hover(
  			  function() {
  			    $("#notificationContainer").show();
  			  }, function() {
  				$("#notificationContainer").hide();
  		});
    	
        $scope.getWorkspaceList();
        $('[data-toggle="tooltip"]').tooltip({title: "Check this checkbox, for repeating utterances", placement: "right"});
        
        var selectIds = $('#collapseDefault,#collapseCommon,#collapseSpecific, #collapseShared');
            selectIds.on('show.bs.collapse hidden.bs.collapse', function () {
                $(this).prev().find('.glyphicon').toggleClass('glyphicon-chevron-down glyphicon-chevron-up');
            });
        
    });
});