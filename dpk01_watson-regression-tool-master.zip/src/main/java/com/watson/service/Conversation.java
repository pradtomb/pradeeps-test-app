package com.watson.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.watson.developer_cloud.conversation.v1.ConversationService;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageRequest;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageResponse;
import com.ibm.watson.developer_cloud.http.HttpHeaders;
import com.watson.bean.ConversationBean;

@Path("/conversation")
public class Conversation {
	
	/**
	 * This method is responsible for sending messages to
	 * conversation service and get a response for user input.
	 * @param data
	 * @param request
	 * @return response Response
	 * @throws IOException
	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/converse")
	public Response sendMessage(String data, @Context HttpServletRequest request) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		try {
			ConversationService service = new ConversationService("2017-02-03");
			Map<String, String> headers = new HashMap<String, String>();
			headers.put(HttpHeaders.X_WATSON_LEARNING_OPT_OUT, "true");
			service.setDefaultHeaders(headers);
			service.setUsernameAndPassword(EnvironmentService.serviceCreadetials.get("userName"), EnvironmentService.serviceCreadetials.get("password"));
			ConversationBean conversationBean = mapper.readValue(data, ConversationBean.class);

			MessageRequest newMessage = new MessageRequest.Builder()
			  .inputText(conversationBean.getCustomerMessage())
			  // Replace with the context obtained from the initial request
			  .context(conversationBean.getContext())
			  .build();
			
			MessageResponse response = service
			  .message(conversationBean.getWorkspace(), newMessage)
			  .execute();
			System.out.println(response);
			return Response.ok(response).header("Content-Type", MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			JSONObject error = new JSONObject();
			error.put("message", e.getMessage());
			return Response.serverError().entity(error.toJSONString()).header("Content-Type", MediaType.APPLICATION_JSON).build();
		}
	}
}
