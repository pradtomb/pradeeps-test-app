'use strict';

airMiles.constant('CONSTANTS', {
	appConfig : {
		globalUrl : './rest/',
		dateFormat : 'yyyy/MM/dd',
		showLoader : 'show_loader',
		multipleUserExportDateFormat: "yyyy-MM-dd HH:mm:ss",
		csvContentType: "data:text/csv;charset=utf-8,",
		blockChainInvoke: "https://7b74f9eb-b622-42ad-9bde-275de77694e0_vp1.us.blockchain.ibm.com:443/chaincode",
		blockChainCHKNInvoke: "https://4ccb733a-0d5a-4cb7-83b2-7c9f07e6e1a1_vp1.us.blockchain.ibm.com:443/chaincode"
	},
	applicationRoles : {
		USER : "user",
		MANAGER : "manager",
		LEAD : "lead"
	},
	responseType : {
		RESULT : "RESULT",
		ERROR : "ERROR"
	},
	responseStatusCodes : {
		SUCCESS : 200,
		NOT_FOUND : 404,
		BAD_REQUEST : 400,
		UNAUTHORIZED : 401
	},
	errorMessages : {
		SAVE_ERROR : "Error in updating activity details",
		SAVE_INPUT_VALID_HOURS: "Please enter valid hours",
		SAVE_EMPTY_ACTIVITY: "Please enter activity name",
		EXPORT_VALID_FROM_DATE: "Please select valid From date",
		EXPORT_VALID_TO_DATE: "Please select valid To date",
		EXPORT_TO_DATE_GREATER: "To date should be greater than From Date",
		DELETE_ACTIVITY:"Either cancel your changes or save unsaved data before deleting",
		SAVE_EMPTY_HOURS: "Please enter hours",
		NO_USER_SELECTED_EXPORT: "Please select atleast one user"
	},
	successMessages : {
		SAVE_SUCCESS : "Activity details updated successfully"
	}

});
