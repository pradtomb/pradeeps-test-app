package com.buddy.app;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;

public class BotCommander {

   public void doBackup() 
   {
     
	   try{
	   String stringUrl = "https://gateway.watsonplatform.net/conversation/api/v1/workspaces/230929e8-62c5-4b13-b405-56c5df32991a?version=2016-07-11&export=true";
        URL url = new URL(stringUrl);
        URLConnection uc = url.openConnection();

        
        //curl -u "{username}":"{password}" "https://gateway.watsonplatform.net/conversation/api/v1/workspaces/394927d3-bf81-40d8-8cb5-368a13f60fee?version=2017-05-26"
        	
        	
        uc.setRequestProperty("X-Requested-With", "Curl");

        String userpass = "4b691cef-59bb-4524-b0c6-fabac6a5ce12" + ":" + "Uqj0hloIcM72";
        String basicAuth = "Basic " + new String(new Base64().encode(userpass.getBytes()));
        uc.setRequestProperty("Authorization", basicAuth);

     //   InputStreamReader inputStreamReader = new InputStreamReader(uc.getInputStream());
        // read this input
        Date date = new Date();
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_hh_mm_ss");
        
        String strdate=sdf.format(date);
       
        System.out.println("C://Application/workspaceBackup"+strdate+".Json");
        OutputStream  outputStream =
                new FileOutputStream(new File("C://Application/workspaceBackup_"+strdate+".Json"));
        
        int read = 0;
		byte[] bytes = new byte[1024];

		while ((read = uc.getInputStream().read(bytes)) != -1) {
			outputStream.write(bytes, 0, read);
		}

		System.out.println("Done!");
	   }
	   catch(Exception ex)
	   {
		   ex.printStackTrace();
	   }
    }
}