package com.buddy.app;


import java.util.*;

import com.ibm.watson.developer_cloud.conversation.v1.ConversationService;
import com.ibm.watson.developer_cloud.conversation.v1.model.Intent;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageRequest;

import okhttp3.Response;


public class ConversationHelper {
	static String workspaceId = "230929e8-62c5-4b13-b405-56c5df32991a"; // replace with your own
	static String userId = "4b691cef-59bb-4524-b0c6-fabac6a5ce12";// replace with your own
	static String password = "Uqj0hloIcM72";// replace with your own
	
	static private String validUIDs = "john,bob,bill";
	static private String userQAArr[][]={
			{"What is your pet name?","Tommy"},
			{"What is your birth city?","Mumbai"},
			{"What is your favorite game?","Cricket"},
			{"What is your favorite food?","Gulab Jamun"},
			};
	static private String current_address=" :Building No. , Floore No. Near your street at Post 410221";
			
	public static synchronized ConversationService getConvService(){
		ConversationService service = new ConversationService("2016-07-11");
		service.setUsernameAndPassword(userId, password);
		return service;
	}
	
	public static synchronized ConversationResponse converse(ConversationResponse convResp){
		MessageRequest newMessage;
		
		if(convResp.service== null){
			convResp.service = getConvService(); 
		}
		if(convResp.response == null || convResp.response.getContext()==null){
				newMessage = new MessageRequest.Builder().inputText(convResp.inputText).build();
		}else{
			newMessage = new MessageRequest.Builder().context(convResp.response.getContext()).inputText(convResp.inputText).build();
		}
		convResp.response  = convResp.service.message(workspaceId, newMessage).execute();
		
		// check if any action coming from the conversation servive

		if(convResp.getResponse().getContext().containsKey("action") 
				&& ! convResp.getResponse().getContext().get("action").equals("")){
			convResp = processResponseForAction(convResp);
		}
	
		return convResp;
	}
	
	@SuppressWarnings("unchecked")
	public static synchronized String getResponseText(ConversationResponse convResp){
		
		String outputStr="I am sorry my brain is not functioning well - echo - "+convResp.inputText;
		if(!convResp.response.getOutput().isEmpty()){
			outputStr = "";
			ArrayList<String> arrayResp =  (ArrayList<String>) convResp.response.getOutput().get("text");
			for(int i=0; i<arrayResp.size(); i++){
				outputStr +=  arrayResp.get(i);
			}
		}
		
		return outputStr;
	}
	
	public static synchronized Intent getIntentFromResponse(ConversationResponse convResp){
		List<Intent> intents  = convResp.response.getIntents();
		return intents.get(0);
	}
	private static String validateUID(String uid){
		String result="false";
		
			if(validUIDs.contains(uid)){
				result="true";
			}
		
		return result;
	}
	
	private static String validatePhone(String phoneNumber){
		String result="false";
		String phno="1231231231";
			if(phoneNumber.equalsIgnoreCase(phno)){
				result="true";
			}
		
		return result;
	}
	
	private static String getQuestion(){
		Random random = new Random();
		int i = random.nextInt(4);
		return userQAArr[i][0];
	}
	
	private static String validateAnswer(ConversationResponse convResp){
		
		String result="false";
		String question  = convResp.getResponse().getContext().get("verification_question").toString();
		String answer  = convResp.getResponse().getContext().get("user_input").toString();
		for(int i=0; i<userQAArr.length; i++){
			if(question.equals(userQAArr[i][0]) && answer.equalsIgnoreCase(userQAArr[i][1])){
				result="true";
				break;
			}
		}
		return result;
	}

	public static synchronized ConversationResponse processResponseForAction(ConversationResponse convResp){
		// if action = 
		//System.out.println("Entry:::"+convResp.getResponse());
		if(convResp.getResponse().getContext().get("action").equals("validate_uid")){
			convResp.inputText = validateUID(convResp.getResponse().getContext().get("user_input").toString());
			convResp = converse(convResp); 
			
		}else if(convResp.getResponse().getContext().get("action").equals("provide_verification_question")){
			@SuppressWarnings("unchecked")
			ArrayList<String> arrayResp =  (ArrayList<String>) convResp.response.getOutput().get("text");
			String question = getQuestion();
			arrayResp.add(question);
			convResp.getResponse().getContext().put("verification_question", question);
			convResp.response.getOutput().put("text", arrayResp);
		} else if(convResp.getResponse().getContext().get("action").equals("validate_verification_question")){
			convResp.inputText = validateAnswer(convResp);
			convResp = converse(convResp);
		} else if(convResp.getResponse().getContext().get("action").equals("validate_phone"))
		{
			convResp.inputText = validatePhone(convResp.inputText);
			convResp.getResponse().getContext().put("action","");
			convResp = converse(convResp);
		}
		else if(convResp.getResponse().getContext().get("action").equals("provide_address"))
		{
			@SuppressWarnings("unchecked")
			ArrayList<String> arrayResp =  (ArrayList<String>) convResp.response.getOutput().get("text");
			String address = current_address;
			arrayResp.add("<b>");
			arrayResp.add(address);
			arrayResp.add("</b>");
			arrayResp.add("Please confim , Would you like to continue with addreess change?");
			convResp.getResponse().getContext().put("current_address", address);
			convResp.response.getOutput().put("text", arrayResp);
			convResp.inputText = "";
			convResp.getResponse().getContext().put("action","");
		}
		else if(convResp.getResponse().getContext().get("action").equals("update_address"))
		{
			@SuppressWarnings("unchecked")
			ArrayList<String> arrayResp =  (ArrayList<String>) convResp.response.getOutput().get("text");
			convResp.getResponse().getContext().put("new_address", convResp.inputText);
			convResp.response.getOutput().put("text", arrayResp);
			convResp.inputText = "true";
			convResp.getResponse().getContext().put("action","");
			convResp = converse(convResp);
		}
		else if(convResp.getResponse().getContext().get("action").equals("backup_workspace"))
		{
			try{
			BotCommander btCom = new BotCommander();
			btCom.doBackup();
			//@SuppressWarnings("unchecked")
			//ArrayList<String> arrayResp =  (ArrayList<String>) convResp.response.getOutput().get("text");
			//convResp.response.getOutput().put("text", arrayResp);
			//convResp.inputText = "";
			//arrayResp.add("c:\backup_path");
			convResp.response.getContext().put("context.backup_path", "c:\\backup_path");
			System.out.println(convResp.response.getContext());
			convResp.getResponse().getContext().put("action","");
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
		
		return convResp;
	}
	


}
